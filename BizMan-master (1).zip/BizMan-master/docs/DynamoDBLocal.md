# DynamoDB Local

Download npm package dynamoadb-admin

Download dynamodb local


use region us-east-1.
