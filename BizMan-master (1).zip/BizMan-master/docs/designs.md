https://dribbble.com/shots/15475625-CRM-Dashboard-Dark-Theme

https://dribbble.com/shots/15469222-AIFlow/attachments/7242034?mode=media

https://dribbble.com/shots/15463425/attachments/7235542?mode=media

https://dribbble.com/shots/15475625-CRM-Dashboard-Dark-Theme

https://dribbble.com/shots/15449715-CRM-Mac-Application/attachments/7220411?mode=media

https://dribbble.com/shots/10428504-Customers-for-YogaPlanner
https://dribbble.com/shots/15220840-SaaS-Task-Management-Dashboard
https://dribbble.com/shots/15347979-Super-busy-UI/attachments/7108189?mode=media
https://dribbble.com/shots/10475418-CMS-Design
https://dribbble.com/shots/9937478-CRMD-Dashboard
https://dribbble.com/shots/14694539-Light-and-Dark-Quick-Actions
https://dribbble.com/shots/15669091-CRM-customer-list
https://dribbble.com/shots/15336336-XSpot-Timeline