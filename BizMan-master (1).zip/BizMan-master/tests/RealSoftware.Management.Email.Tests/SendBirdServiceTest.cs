﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Microsoft.Extensions.Configuration;
using RealSoftware.Management.Email.Services;
using RealSoftware.Management.ReadModel.Repo;
using SendGrid.Helpers.Mail;
using Xunit;

namespace RealSoftware.Management.Email.Tests
{
    public class SendBirdServiceTest
    {
        private IConfiguration _configuration;
        public SendBirdServiceTest()
        {
            var builder = new ConfigurationBuilder();

            builder.AddInMemoryCollection(new Dictionary<string, string>
            {
                { "SendGrid:ApiKey", "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" }
            });
            _configuration = builder.Build();
        }
        [Fact]
        public void Ensure_To_Send_Email_Successfull()
        {
            SendGirdEmailService emailService = new SendGirdEmailService(_configuration);
            var emailAddress = new EmailAddress()
            {
                Email = "markchristopher.cacal@gmail.com",
                Name = "mark christopher cacal"
            };
            var res = emailService.SendEmail(emailAddress, "ensure_to_send_email_successful", "test", "test",
                emailAddress).Result;

            Assert.Equal(HttpStatusCode.Accepted, res.StatusCode);
        }
    }
}
