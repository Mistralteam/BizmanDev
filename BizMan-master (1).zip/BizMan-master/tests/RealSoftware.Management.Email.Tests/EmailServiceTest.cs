using System;
using System.Threading.Tasks;
using MailKit.Net.Smtp;
using Moq;
using RealSoftware.Management.Email.Services;
using Xunit;

namespace RealSoftware.Management.Email.Tests
{
    public class EmailServiceTest
    {
        [Fact]
        public async Task Ensure_EmailService_CanSendEmail()
        {
            SmtpClient smtpClient = new SmtpClient();
            await smtpClient.ConnectAsync("smtp.gmail.com", 587, false);
            await smtpClient.AuthenticateAsync("youremail", "password");

            EmailService emailService = new EmailService(smtpClient);
            /*var emailService = new Mock<IEmailService>();*/
            
            await emailService.SendEmail(new Model.EmailModel()
            {
                To = new System.Collections.Generic.List<string>() { "markchristopher.cacal@gmail.com" },
                Body = "Test",
                From= "markchristopher.cacal@gmail.com",
                Subject="test"
            });
        }
    }
}
