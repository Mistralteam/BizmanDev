using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using HtmlAgilityPack;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Hosting;
using Moq;
using RealSoftware.Management.Email.Services;
using Xunit;

namespace RealSoftware.Management.Email.Tests
{
    public class EmailTemplateServiceTest
    {
        private IDynamoDBContext db;
        public EmailTemplateServiceTest()
        {
            db = new DynamoDBContext(new AmazonDynamoDBClient(new AmazonDynamoDBConfig()
            {
                ServiceURL = "http://127.0.0.1:8000"
            }));
        }
        [Fact]
        public async Task Ensure_EmailTemplateService_CanParseWelcomeEmail()
        {
            EmailTemplateService emailTemplateService = new EmailTemplateService(db);
            var html =await emailTemplateService.RenderTemplate("Welcome", new
            {
                FirstName = "Mark Christopher"
            });
            Assert.NotEmpty( html);

            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml( html);
            var firstName = htmlDoc.GetElementbyId("firstname").InnerText;
            Assert.Equal("Mark Christopher", firstName);

        }
        [Fact]
        public async Task Ensure_EmailTemplateService_CanParseDocumentReceivedEmail()
        {
            EmailTemplateService emailTemplateService = new EmailTemplateService(db);
            var html = emailTemplateService.RenderTemplate("DocumentReceived", new
            {
                FirstName = "Mark Christopher",
                Name = "Mark Christopher R. Cacal"
            });
            Assert.NotEmpty(await html);
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                $"{nameof(Ensure_EmailTemplateService_CanParseDocumentReceivedEmail)}.html");
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(await html);
            var firstName = htmlDoc.GetElementbyId("firstname").InnerText;
            Assert.Equal("Mark Christopher", firstName);
            var htmlNodes = htmlDoc.DocumentNode.SelectNodes("//ul/li");
            foreach (var node in htmlNodes)
            {
                var name = node.Element("span");

                Assert.Equal("Mark Christopher R. Cacal", name.InnerHtml);
            }

        }
        [Fact]
        public async Task Ensure_EmailTemplateService_CanParseReadyToGoLiveEmail()
        {
            EmailTemplateService emailTemplateService = new EmailTemplateService(db);
            var html = await emailTemplateService.RenderTemplate("ReadyToGoLive", new
            {
                FirstName = "Mark Christopher",
                Date = "4/13/2021",
                Name = "Mark Christopher R. Cacal"
            });
            Assert.NotEmpty( html);
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                $"{nameof(Ensure_EmailTemplateService_CanParseReadyToGoLiveEmail)}.html");
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml( html);
            var firstName = htmlDoc.GetElementbyId("firstname").InnerText;
            Assert.Equal("Mark Christopher", firstName);
            var startDate = htmlDoc.GetElementbyId("start-date").InnerText;
            Assert.Equal("4/13/2021", startDate);

        }
        [Fact]
        public async Task Ensure_EmailTemplateService_CanParseAppIsLiveEmail()
        {
            EmailTemplateService emailTemplateService = new EmailTemplateService(db);
            var html = await emailTemplateService.RenderTemplate("AppIsLive", new
            {
                FirstName = "Mark Christopher"
            });
            Assert.NotEmpty( html);
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml( html);
            var firstName = htmlDoc.GetElementbyId("firstname").InnerText;
            Assert.Equal("Mark Christopher", firstName);

        }

    }
}
