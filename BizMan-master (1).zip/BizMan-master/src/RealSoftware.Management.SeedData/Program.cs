﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
// using MySqlConnector;
using NEvilES.Abstractions.Pipeline;
using NEvilES.Abstractions.Pipeline.Async;
using NEvilES.DataStore.DynamoDB;
using NEvilES.Extensions.DependecyInjection;
// using RealSoftware.Crm.Common;
// using RealSoftware.Crm.ReadModel.Ext;
using RealSoftware.Common.NEvilES;
using RealSoftware.Management.Common;
// using RepoDb;

namespace RealSoftware.Crm.SeedData
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            // Environment.SetEnvironmentVariable("AWS_REGION", "us-east-1");

            var host = CreateHostBuilder(args).Build();

            var a = host.Services.GetService<DynamoCreateTables>();
            await a.TryCreateTables();
            /*var a1 = host.Services.GetService<EventSeeder>();
            await a1.Seed();*/
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseConsoleLifetime()
                .ConfigureServices((hostContext, services) =>
                {

                    services.AddSharedServices(hostContext.Configuration);


                    services.AddSingleton<DynamoReadWriteModel>();
                    services.AddSingleton<IReadFromReadModelAsync2>(s => s.GetRequiredService<DynamoReadWriteModel>());
                    services.AddSingleton<IWriteReadModelAsync>(s => s.GetRequiredService<DynamoReadWriteModel>());

                    var prefix = hostContext.Configuration.GetValue<string>("DynamoDbSettings:TablePrefix") ?? string.Empty;
                    if (!string.IsNullOrWhiteSpace(prefix))
                    {
                        TableConstants.EVENT_TABLE_NAME = prefix + TableConstants.EVENT_TABLE_NAME;
                    }

                    services.AddEventStore<DynamoDBEventStore, DynamoDBTransaction>(opts =>
                    {
                       opts.DomainAssemblyTypes = new List<Type>{
                            typeof(Management.Contracts.Agency),
                            typeof(Management.Domain.Agency)
                        };

                        opts.GetUserContext = s => new SeedDataUser();

                        opts.ReadModelAssemblyTypes = new List<Type>{
                            // typeof(Management.ReadModel.Agency),
                            typeof(Management.ReadModel.Projectors.AgencyProjector)
                        };
                    });

                    services.AddScoped<DynamoCreateTables>();
                    services.AddScoped<EventSeeder>();
                });
    }


    public class SeedDataUser : IUser
    {
        public Guid GuidId => Guid.Parse("1fb46389-571c-4c16-82a6-9d9c0f471cfb");
    }
}
