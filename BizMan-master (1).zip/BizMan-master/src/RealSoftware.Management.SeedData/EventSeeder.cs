﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NEvilES;
using NEvilES.Abstractions;
using NEvilES.Abstractions.Pipeline.Async;

namespace RealSoftware.Crm.SeedData
{

    public class EventSeeder
    {
        private readonly IAsyncCommandProcessor _commandProcessor;
        private readonly ILogger<EventSeeder> _logger;

        public EventSeeder(
            ILogger<EventSeeder> logger,
            IAsyncCommandProcessor commandProcessor
            )
        {
            _logger = logger;
            _commandProcessor = commandProcessor;
        }

        public async Task Seed()
        {



            var id = Guid.NewGuid();
            await RunCommands(
                new Management.Contracts.Agency.OnBoardNewAgency
                {
                    StreamId = Guid.NewGuid(),
                    AgencyName = "Buxton St Kilda",
                    PrimaryContact = new Management.Contracts.Agency.Contact
                    {
                        Email = "it.realsoftware@gmail.com",
                        FirstName = "Elijah",
                        LastName = "Bux STK",
                        Mobile = "04340 000 433"
                    }
                },
                new Management.Contracts.Agent.AddAgent
                {
                    StreamId = Guid.NewGuid(),
                    Email = "elijahbate@gmail.com",
                    AgencyId = Guid.NewGuid(),
                    FirstName = "Elijah",
                    LastName = "B. Agent",
                    ReaAgentId = "454545"
                }
                // new Management.Contracts.EmailTemplate.AddEmailTemplate
                // {
                //     StreamId=Guid.NewGuid(),
                //     Id= Guid.NewGuid(),
                //     Template= "<p class=\"salutation\">\r\n\tHi <span id=\"firstname\">{{FirstName}}</span>,\r\n</p>\r\n<p>We are pleased to advise that your Real Facebook App has been connected and is now live!</p>\r\n<p>We hope you are happy with how it looks, and the service we have provided.</p>\r\n<p>Please don’t hesitate to call us if you have any queries or concerns.</p>\r\n<p>Thank you for your business.</p>\r\n<p>PS – if you are happy with our service we would greatly appreciate your testimonial either via email</p>\r\n<p>or on our Facebook page <a href=\"facebook.com/realsoftwareau\">facebook.com/realsoftwareau</a>Kind regard</p>",
                //     Name="AppIsLive"
                // },
                // new Management.Contracts.EmailTemplate.AddEmailTemplate
                // {
                //     StreamId = Guid.NewGuid(),
                //     Id = Guid.NewGuid(),
                //     Template = "<p class=\"salutation\">Hi <span id=\"firstname\">{{FirstName}}</span>,</p>\r\n<p>Thank you for signing our Proposal, we are excited to be working with you to set up your new</p>\r\n<p>Facebook App.</p>\r\n<p>So that we can get your App connected, could you please email me back with the following at your</p>\r\n<p>earliest opportunity:</p>\r\n<ul>\r\n<li>Complete the attached form</li>\r\n</ul>\r\n<p>[https://drive.google.com/file/d/1QDcobMF8QI0cn4HfHIHggrJIIhIazTrh/view?usp=sharing]</p>\r\n<ul>\r\n<li>High resolution version of your logo</li>\r\n<li>Feature image – this image will be at the top of the page, and could be a photo of your office,</li>\r\n</ul>\r\n<p>staff group photo, or location image</p>\r\n<ul>\r\n<li>Staff contact details (phone & email address) and profile pictures – for those who are on your</li>\r\n</ul>\r\n<p>listings</p>\r\n<p>If you have any queries please don’t hesitate to give me a call on 0405 213 203.</p>\r\n<p> </p>",
                //     Name = "Welcome"
                // },
                // new Management.Contracts.EmailTemplate.AddEmailTemplate
                // {
                //     StreamId = Guid.NewGuid(),
                //     Id = Guid.NewGuid(),
                //     Template = "<p class=\"salutation\">\r\n\tHi <span id=\"firstname\">{{FirstName}}</span>,\r\n</p>\r\n<p>We are ready to launch your Facebook App!</p>\r\n<p>The final step is to set up your direct debit for the ongoing monthly payments of $55 from <span id=\"start-date\">{{Date}}</span>\r\n(this takes into account your 1 month free). I have just sent {{Name}} a request via our merchant</p>\r\n<p>provider PayAdvantage to complete this process.</p>\r\n<p>Please let me know once this has completed this so we can make your site live.</p>\r\n<p>If you have any queries at all please don’t hesitate to call me. 😊</p>\r\n<p>Kind regards,</p>",
                //     Name = "ReadyToGoLive"
                // },
                // new Management.Contracts.EmailTemplate.AddEmailTemplate
                // {
                //     StreamId = Guid.NewGuid(),
                //     Id = Guid.NewGuid(),
                //     Template = "<p class=\"salutation\">\r\n\tHi <span id=\"firstname\">{{FirstName}}</span>,\r\n</p>\r\n<p>Thanks so much for organising all of this.</p>\r\n<p>I have just sent the following:</p>\r\n<ul>\r\n\t<li >A request to <span class=\"name\">{{Name}}</span> from Facebook seeking Admin Access your Company’s Page.</li>\r\n\t<li >A request to <span class=\"name\">{{Name}}</span> via SMS and/or email from our merchant provider, PayAdvantage, to</li>\r\n</ul>\r\n<p>complete payment for the setup costs.Could you kindly complete these as soon as possible so we can commence setup of the App.</p>\r\n<p>In the meantime if you have any queries at all, please don’t hesitate to give me a call.</p>\r\n<p>Kind regards,</p>",
                //     Name = "DocumentReceived"
                // }
            );

            _logger.LogInformation("Seed data complete. Stopping.");
        }

        private async Task RunCommands(params IMessage[] messages)
        {
            foreach (var msg in messages)
            {
                try
                {

                    var result = await _commandProcessor.ProcessAsync(msg);
                    if (result.Response is CommandRejectedWithError<string> error)
                    {
                        throw new Exception($"An error occur processing command {msg.GetType().FullName}, StreamId {msg.StreamId}. Error: {error.CommandError}");
                    }
                }
                catch (DomainAggregateException ex)
                {
                    throw new Exception($"An error occur processing command {msg.GetType().FullName}, StreamId {msg.StreamId}. Error: {ex.Message}");
                }


            }
        }


    }
}