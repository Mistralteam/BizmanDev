using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NEvilES.Abstractions.Pipeline.Async;
using NEvilES.DataStore.DynamoDB;

namespace RealSoftware.Crm.SeedData
{

    public class DynamoCreateTables
    {
        private readonly ILogger<DynamoCreateTables> _logger;
        private readonly IAmazonDynamoDB _dynamoDBClient;

        public DynamoCreateTables(ILogger<DynamoCreateTables> logger, IAmazonDynamoDB dynamoDBClient)
        {
            _logger = logger;
            this._dynamoDBClient = dynamoDBClient;
        }

        public async Task TryCreateTables()
        {
            var dynamoDBContext = new DynamoDBContext(_dynamoDBClient);


            string eventStoreTableName = AWSConfigsDynamoDB.Context.TableNamePrefix + "eventstore";
            string readmodelsTableName = AWSConfigsDynamoDB.Context.TableNamePrefix + "readmodels";

            var tables = await _dynamoDBClient.ListTablesAsync();

            if (!tables.TableNames.Contains(eventStoreTableName))
            {
                await CreateEventStoretable(eventStoreTableName);
                _logger.LogInformation("EventStore Db Table Created");
            }
            else
            {
                _logger.LogInformation("EventStore Db Table already exists. No action required.");
            }

            if (!tables.TableNames.Contains(readmodelsTableName))
            {
                await CreateReadModelsTable(readmodelsTableName);
                _logger.LogInformation("ReadModel Db Table Created");
            }
            else
            {
                _logger.LogInformation("ReadModel Db Table already exists. No action required.");
            }
           ;
            return;
        }

        private Task<CreateTableResponse> CreateEventStoretable(string tableName)
        {
            var createTableRequest = new CreateTableRequest
            {
                TableName = tableName,
                GlobalSecondaryIndexes = new List<GlobalSecondaryIndex>()
                {
                    new GlobalSecondaryIndex
                    {
                        IndexName = "CommitedAt-Version-Index",
                        KeySchema = new List<KeySchemaElement>{
                            new KeySchemaElement{
                                AttributeName =nameof(DynamoDBEventTable.CommmitedAt),
                                KeyType = KeyType.HASH
                            },
                            new KeySchemaElement{
                                AttributeName =nameof(DynamoDBEventTable.Version),
                                KeyType = KeyType.RANGE
                            }
                        },
                        Projection = new Projection{
                            ProjectionType = ProjectionType.ALL
                        }
                    }
                },
                KeySchema = new List<KeySchemaElement>{
                    new KeySchemaElement{
                        AttributeName = nameof(DynamoDBEventTable.StreamId),
                        KeyType = KeyType.HASH
                    },
                    new KeySchemaElement{
                        AttributeName =nameof(DynamoDBEventTable.Version),
                        KeyType = KeyType.RANGE
                    }
                },
                BillingMode = BillingMode.PAY_PER_REQUEST,
                AttributeDefinitions = new List<AttributeDefinition>{
                    new AttributeDefinition{
                        AttributeName = nameof(DynamoDBEventTable.StreamId),
                        AttributeType = ScalarAttributeType.S
                    },
                    new AttributeDefinition{
                        AttributeName = nameof(DynamoDBEventTable.Version),
                        AttributeType = ScalarAttributeType.N
                    },
                    new AttributeDefinition{
                        AttributeName = nameof(DynamoDBEventTable.CommmitedAt),
                        AttributeType = ScalarAttributeType.N
                    },
                }
            };

            return _dynamoDBClient.CreateTableAsync(createTableRequest);
        }
        private Task<CreateTableResponse> CreateReadModelsTable(string tableName)
        {
            var createTableRequest = new CreateTableRequest
            {
                TableName = tableName,
                KeySchema = new List<KeySchemaElement>{
                    new KeySchemaElement{
                        AttributeName ="StreamId",
                        KeyType = KeyType.HASH
                    },
                    new KeySchemaElement{
                        AttributeName ="TypeName",
                        KeyType = KeyType.RANGE
                    }
                },
                BillingMode = BillingMode.PAY_PER_REQUEST,
                AttributeDefinitions = new List<AttributeDefinition>{
                    new AttributeDefinition{
                         AttributeName ="StreamId",
                        AttributeType = ScalarAttributeType.S
                    },
                    new AttributeDefinition{
                        AttributeName ="TypeName",
                        AttributeType = ScalarAttributeType.S
                    },

                }
            };

            return _dynamoDBClient.CreateTableAsync(createTableRequest);
        }
    }
}