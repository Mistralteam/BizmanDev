﻿using System;
using System.Collections.Generic;
using System.Text;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class EmailTemplate
    {
        public class AddEmailTemplate:ICommand
        {
            public Guid StreamId { get; set; }
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string Template { get; set; }
        }
        public class AddedEmailTemplate :AddEmailTemplate, IEvent
        {
            
        }
    }
}
