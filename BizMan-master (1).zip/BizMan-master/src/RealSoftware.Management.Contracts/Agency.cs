﻿using System;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class Agency
    {

        public class OnBoardNewAgency : ICommand
        {
            public Guid StreamId { get; set; }
            public string AgencyName { get; set; }
            public Contact PrimaryContact { get; set; }

        }

        public class OnBoardedNewAgency : IEvent
        {
            public Guid StreamId { get; set; }
            public string AgencyName { get; set; }
            public Contact PrimaryContact { get; set; }
        }


        public class AddAdditionalContact : ICommand
        {
            public Guid StreamId { get; set; }
            public Contact Contact { get; set; }
            public string ContactType { get; set; }
        }

        public class ContactAdded : IEvent
        {
            public Guid StreamId { get; set; }
            public Contact Contact { get; set; }
            public string ContactType { get; set; }
        }

        public class Contact
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Mobile { get; set; }
            public string BusinessPhone { get; set; }
        }


    }
}
