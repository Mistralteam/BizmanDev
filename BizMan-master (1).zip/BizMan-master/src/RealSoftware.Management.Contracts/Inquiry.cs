using System;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class Inquiry
    {

        public class NewWebsiteInquiry : ICommand
        {
            public Guid StreamId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Phone { get; set; }
            public string Interests { get; set; }
            public string Notes { get; set; }
        }

        public class WebsiteInquiryReceived : IEvent
        {
            public Guid StreamId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Phone { get; set; }
            public string Interests { get; set; }
            public string Notes { get; set; }
        }

        public class NewWebsiteAppraisal : ICommand
        {
            public Guid StreamId { get; set; }
        }

        public class WebsiteAppraisalRequestReceived : IEvent
        {
            public Guid StreamId { get; set; }
        }

        public class REAInquiryReceived : IEvent
        {
            public Guid StreamId { get; set; }
        }
    }
}