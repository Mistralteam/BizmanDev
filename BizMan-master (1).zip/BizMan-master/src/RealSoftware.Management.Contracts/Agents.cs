﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class Agents
    {
        public class AddAgent : ICommand
        {
            public Guid StreamId { get; set; }
            public string Email { get; set; }
            public string Mobile { get; set; }
            public string Name { get; set; }
            public IFormFile Image { get; set; }
            public Guid ClientId { get; set; }
        }

        public class AddedAgent : AddAgent, IEvent
        {
            public string ProfilePicture { get; set; }
        }
    }
}
