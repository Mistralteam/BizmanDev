using System;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class Agent
    {

        public class AddAgent : ICommand
        {
            public Guid StreamId { get; set; }
            public Guid AgencyId { get; set; }
            public string ReaAgentId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
        }

        public class AgentCreated : IEvent
        {
            public Guid StreamId { get; set; }
            public Guid AgencyId { get; set; }
            public string ReaAgentId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
        }

        public class AgentImageUpdated : IEvent
        {
            public Guid StreamId { get; set; }
            // S3 Bucket
            public string StorageContainer { get; set; }
            public string ObjectKey { get; set; }
            public string FileName { get; set; }
        }

        public class AgentNameChanged : IEvent
        {
            public Guid StreamId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }

        // public class AgentRequetedNewEmailVerification : IEvent
        // {
        //     public Guid StreamId { get; set; }
        //     public string VerificationToken
        // }
    }
}