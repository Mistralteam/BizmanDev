﻿using System;
using System.Collections.Generic;
using System.Text;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Contracts
{
    public abstract class ApplicationForm
    {
        public class AddFile:ICommand
        {
            public Guid StreamId { get; set; }
            public List<byte[]> Files { get; set; }
        }
    }
}
