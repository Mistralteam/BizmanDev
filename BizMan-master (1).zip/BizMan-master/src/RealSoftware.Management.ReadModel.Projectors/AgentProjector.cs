using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using NEvilES.Abstractions.Pipeline;

namespace RealSoftware.Management.ReadModel.Projectors
{
    public class AgentProjector :
        IProjectAsync<Contracts.Agent.AgentCreated>
    {
        private readonly IDynamoDBContext _dynamoDBContext;
        public AgentProjector(IDynamoDBContext dynamoDBContext)
        {
            this._dynamoDBContext = dynamoDBContext;
        }

        public Task ProjectAsync(Contracts.Agent.AgentCreated message, IProjectorData data)
        {
            var agent = new ReadModel.Agent
            {

            };


            return _dynamoDBContext.SaveAsync(agent);
        }
    }
}