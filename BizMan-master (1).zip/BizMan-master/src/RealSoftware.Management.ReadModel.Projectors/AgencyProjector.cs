﻿using System;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using NEvilES.Abstractions.Pipeline;

namespace RealSoftware.Management.ReadModel.Projectors
{
    public class AgencyProjector :
        IProjectAsync<Contracts.Agency.OnBoardedNewAgency>
    {

        private readonly IDynamoDBContext _dynamoDBContext;
        public AgencyProjector(IDynamoDBContext dynamoDBContext)
        {
            this._dynamoDBContext = dynamoDBContext;
        }

        public async Task ProjectAsync(Contracts.Agency.OnBoardedNewAgency message, IProjectorData data)
        {
            // var agency = new ReadModel.Agency
            // {
            //     Id = message.StreamId,
            //     Name = message.AgencyName,

            // };

            // return _dynamoDBContext.SaveAsync(agency);
        }
    }
}
