﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using NEvilES.Abstractions.Pipeline;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.Contracts;

namespace RealSoftware.Management.ReadModel.Projectors
{
    public class AgentsProjector :
        IProjectAsync<Agents.AddedAgent>
    {
        private readonly IAgentRepository _agentRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IConfiguration _configuration;
        private readonly IFileStorage _fileStorage;

        public AgentsProjector(IAgentRepository agentRepository, IClientRepository clientRepository, IConfiguration configuration, IFileStorage fileStorage)
        {
            _agentRepository = agentRepository;
            _clientRepository = clientRepository;
            _configuration = configuration;
            _fileStorage = fileStorage;
        }
        public async Task ProjectAsync(Agents.AddedAgent message, IProjectorData data)
        {
            var client = await _clientRepository.GetByIdAsync(message.ClientId);
            var resourcePath =
                $"img/{client.Name.Replace(" ", "-")}/{message.Name.Replace(" ", "-").Replace("'", "")}.jpg";
            var url = $"{_configuration["PublicCdnUrl"]}/{resourcePath}";
            Stream originalImage = new MemoryStream();
            await message.Image.CopyToAsync(originalImage);
            originalImage.Position = 0;
            await _fileStorage.SaveFile(originalImage, _configuration["PublicCdnBucketName"], resourcePath);

            await _agentRepository.Save(new Listing.ReadModels.Agent()
            {
                AgentId = message.StreamId.ToString(),
                ClientId = message.ClientId,
                Email = message.Email,
                Id = message.StreamId,
                Mobile = message.Mobile,
                Name = message.Name,
                ProfilePicture = url
            });
        }
    }
}
