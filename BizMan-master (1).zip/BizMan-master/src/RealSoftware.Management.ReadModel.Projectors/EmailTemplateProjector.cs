﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using NEvilES.Abstractions.Pipeline;

namespace RealSoftware.Management.ReadModel.Projectors
{
    public class EmailTemplateProjector : IProjectAsync<Contracts.EmailTemplate.AddedEmailTemplate>
    {
        private readonly IDynamoDBContext _db;

        public EmailTemplateProjector(IDynamoDBContext db)
        {
            _db = db;
        }
        public async Task ProjectAsync(Contracts.EmailTemplate.AddedEmailTemplate message, IProjectorData data)
        {
            await _db.SaveAsync(new ReadModel.EmailTemplate()
            {
                Id = message.Id,
                Name = message.Name,
                Template = message.Template
            });
        }
    }
}
