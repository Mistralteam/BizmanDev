const path = require("path");
const webpack = require("webpack");

module.exports = {
  entry: "./src/index.tsx",

  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: ["ts-loader"],
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: [".ts", ".js", ".tsx", ".jsx"],
  },
  output: {
    path: path.join(__dirname, "dist"),
    filename:
      process.env.NODE_ENV === "production" ? "rs.lib.min.js" : "rs.lib.js",
    libraryExport: "default",
    library: "rs",
  },
};
