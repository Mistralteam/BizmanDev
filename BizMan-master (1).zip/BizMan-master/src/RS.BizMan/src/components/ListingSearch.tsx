import React, { useState, useEffect } from "react";
import useDebounce from "./Debounce";
import { Listing } from "./Listings/Index";
import { Listings } from "./Models/Listings";

interface ListingSearchProps {
  listingApiUrl: string;
  displayType: "Grid" | "List";
  listingsPerPage: number;
  clientId: string;
}

export const ListingSearch = ({
  displayType,
  listingApiUrl,
  listingsPerPage,
  clientId
}: ListingSearchProps) => {
  const [getListing, setListing] = useState<Listings[]>([]);
  const [searchValue, setSearchValue] = useState("");
  const debouncedValue = useDebounce<string>(searchValue, 1500)

  const getAllListingProperty = async () => {
    const get = await fetch(`${listingApiUrl}/api/listingapi?search=${searchValue}&clientId=${clientId}` ).then(data=>data.json()).then(data=> setListing(data as any as Listings[]));
    console.log(getListing);
  };
  function Search(event) {
    setSearchValue(event.target.value);

  }
  useEffect(() => {
    getAllListingProperty();
  }, [debouncedValue]);
  return (
    <>
      <input
        type="text"
        className="form-control"
        placeholder="search"
        onChange={Search}
      />
      <Listing listing={getListing} />
      <div>
        <p>Props Values {getListing.length}</p>
        <span>Display Type: {displayType}</span>
      </div>
    </>
  );
};
