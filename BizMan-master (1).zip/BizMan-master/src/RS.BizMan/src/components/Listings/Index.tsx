import React from "react";
import { ListingsProps } from "../Models/ListingProps";
import { Listings } from "../Models/Listings";

export const Listing = ({ listing }: ListingsProps) => {
  var _listing = listing as any as Listings[];
  return (
    <>
      <table className="table">
        <thead>
          <tr>
            <th>CLIENT </th>
            <th>UNIQUE ID</th>
            <th>LISTING ID</th>
            <th>STATUS</th>
            <th>ADDRESS</th>
          </tr>
        </thead>
        <tbody>
          {_listing.map((listing) => {
            return (
              <tr>
                <td>{listing.clientId}</td>
                <td>{listing.uniqueId}</td>
                <td>{listing.listingId}</td>
                <td>{listing.propertyStatus}</td>
                <td>{listing.address?.fullAddress}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
};
