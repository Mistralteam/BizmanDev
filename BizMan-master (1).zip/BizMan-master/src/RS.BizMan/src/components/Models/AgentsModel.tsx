export interface AgentsModel  {
  profilePicture: string;
  id: string;
  clientId: string;
  name: string;
  email: string;
  mobile: string;
};
