export interface AgentsProp {
  apiUrl: string;
  addApiUrl: string;
  updateApiUrl: string;
  deleteApiUrl: string;
  clientId: string;
}
