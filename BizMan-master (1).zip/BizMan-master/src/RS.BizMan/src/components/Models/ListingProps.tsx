import { Listings } from "./Listings";

export interface ListingsProps{
    listing:Listings[]
}