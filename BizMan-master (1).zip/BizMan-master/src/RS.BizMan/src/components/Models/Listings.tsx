export interface Listings{
    clientId: string,
    uniqueId:string,
    listingId:string,
    propertyStatus:string,
    address:Address
}
interface Address{
    fullAddress:string
}
