import React from "react";
import { AgentsModel } from "../Models/AgentsModel";
export interface AgentListProp {
  agents: AgentsModel[];
  isLoading: boolean;
  clientId: string;
}
export const AgentList = ({ agents, isLoading, clientId }: AgentListProp) => {
  return (
    <>
      <table className="table table-striped">
        <thead>
          <th>#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Mobile</th>
        </thead>
        <tbody>
          {isLoading && (
            <tr>
              <td colSpan={4}>Loading...</td>
            </tr>
          )}
          {!isLoading &&
            agents.map((agent) => {
              return (
                <>
                  <tr>
                    <td>
                      <a href={`/clients/${clientId}/agent/${agent.id}`}>
                        <span className="fa fa-pencil"></span>
                      </a>
                    </td>
                    <td>{agent.name}</td>
                    <td>{agent.email}</td>
                    <td>{agent.mobile}</td>
                  </tr>
                </>
              );
            })}
        </tbody>
      </table>
    </>
  );
};
