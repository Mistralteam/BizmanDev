import React, { useEffect, useState } from "react";
import { listAgents } from "../ApiClients/AgentClients";
import { AgentsModel } from "../Models/AgentsModel";
import { AgentsProp } from "../Models/AgentsProp";
import { AddEditAgent } from "./AddEditAgent";
import { AgentList } from "./AgentList";
import { ImageCropper } from "./ImageCropper";

export const AgentComponent = ({
  apiUrl,
  addApiUrl,
  updateApiUrl,
  deleteApiUrl,
  clientId,
}: AgentsProp) => {
  const [isLoading, setLoading] = useState(true);
  const [getAgents, setAgents] = useState<AgentsModel[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [cropper, setShowCropper] = useState(false);
  const [getImgSrc, setImageSrc] = useState("");

  
  function onCancel() {
    setShowModal(false);
  }
 
  useEffect(() => {
    async function getAgents() {
      const agents = await listAgents({ apiUrl });
      setAgents(agents);
      setLoading(false);
    }
    if (isLoading) {
      getAgents();
    }
  }, [isLoading]);

  return (
    <>
      <div className="card">
        <div className="card-header">
          <a href={`/clients/${clientId}/agent`}
            className="btn btn-primary"
          >
            Add
          </a>
        </div>
        <div className="card-body">
          <AgentList
            isLoading={isLoading}
            agents={getAgents}
            clientId={clientId}
          />
        </div>
      </div>

     
    </>
  );
};
