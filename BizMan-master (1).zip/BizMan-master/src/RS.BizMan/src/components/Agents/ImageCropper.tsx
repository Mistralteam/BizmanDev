import React, { useCallback, useState } from "react";
import Cropper from "react-easy-crop";
import Slider from "@material-ui/core/Slider";
export const ImageCropper = ({ imgSrc, hideCropper,setCroppedArea }) => {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState<number>(1);
  const onCropComplete = useCallback((croppedArea, croppedAreaPixels) => {
     setCroppedArea({croppedArea, croppedAreaPixels})
  }, []);
  return (
    <>
      <div className={`modal show show-dialog`} role="dialog" >
        <div className={`modal-dialog modal-lg`} role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Image Cropper</h5>
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
                onClick={hideCropper}
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body cropper-min-height-250" >
              <Cropper
                image={imgSrc}
                crop={crop}
                zoom={zoom}
                aspect={4 / 4}
                onCropChange={setCrop}
                onCropComplete={onCropComplete}
                onZoomChange={setZoom}
              />
              <div className="row">
                <div className="col-12">
                  <div className="controls">
                    <Slider
                      value={zoom}
                      min={1}
                      max={3}
                      step={0.1}
                      aria-labelledby="Zoom"
                      onChange={(e, zoom: number) => setZoom(zoom)}
                      classes={{ root: "slider" }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="submit" className="btn btn-primary" onClick={hideCropper}>
                Save changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
