import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { addAgentClient, getAgentByIdClient } from "../ApiClients/AgentClients";
import { getCroppedImg } from "../cropImage";
import { AgentsModel } from "../Models/AgentsModel";
import { ImageCropper } from "./ImageCropper";

const Spinner = () => {
  return (
    <div className="spinner-border spinner-border-sm" role="status">
      <span className="sr-only">Loading...</span>
    </div>
  );
};

interface CroppedArea {
  croppedArea: any;
  croppedAreaPixels: any;
}
interface addEditAgentProp {
  addApiUrl;
  clientId;
  agentId;
  detailApiUrl;
}
export const AddEditAgent = ({
  detailApiUrl,
  addApiUrl,
  clientId,
}: addEditAgentProp) => {
  const [imgSrc, setImgSrc] = useState("");
  const [imgBlob, setImgBlob] = useState<Blob>();
  const [cropper, setShowCropper] = useState(false);
  const [getImgSrc, setImageSrc] = useState("");
  const [croppedArea, setCroppedArea] = useState<CroppedArea>();
  const [originalFile, setOriginalFile] = useState("");
  const [agentDetail, setAgentDetail] = useState<AgentsModel>();
  const [isLoading, setLoading] = useState(true);
  function onFileChange(event) {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      var url = URL.createObjectURL(file);
      setOriginalFile(url);
      setImgSrc(url);

      setImgBlob(file);
    }
  }

  function showCropper(imgSrc) {
    setShowCropper(true);
    setImageSrc(imgSrc);
  }
  async function hideCropper() {
    setShowCropper(false);
    const img = await getCroppedImg(
      originalFile,
      croppedArea.croppedAreaPixels,
      0
    );
    setImgBlob(img as any);

    const newImgSrcUrl = URL.createObjectURL(img);
    setImgSrc(newImgSrcUrl);
  }
  async function onAddEditAgent(data) {
    data.croppedArea = croppedArea;
    data.ImageBlob = imgBlob;
    data.clientId = clientId;
    await addAgentClient({ addApiUrl, data });
  }

  const {
    register,
    setValue,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm();

  const onSubmit = async (data) => {
    await onAddEditAgent(data);
  };
  const setValues = (agent) => {
    setValue("name", agent?.name, { shouldValidate: true });
    setValue("email", agent?.email, { shouldValidate: true });
    setValue("mobile", agent?.mobile, { shouldValidate: true });
  };
  useEffect(() => {
    const getAgentById = async () => {
      var agent = await getAgentByIdClient(detailApiUrl);
      setAgentDetail(agent);
      setImgSrc(agent.profilePicture);
      setOriginalFile(agent.profilePicture);
      setLoading(false);
      setValues(agent);
    };
    if (isLoading) {
      getAgentById();
    }
  }, [isLoading]);
  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="row">
          <div className="col-12">
            <label htmlFor="name">Name</label>
            <input
              {...register("name", { required: true })}
              className="form-control"
            />
            <p>{errors.name && "Name is required"}</p>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <label htmlFor="email">Email</label>
            <input
              {...register("email", { required: true })}
              className="form-control"
            />
            <p>{errors.email?.message}</p>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <label htmlFor="mobile">Mobile</label>
            <input
              {...register("mobile", { required: true })}
              className="form-control"
              defaultValue={agentDetail?.mobile}
            />
            <p>{errors.mobile?.message}</p>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <div className="row">
              <div className="col-3 ">
                <img
                  src={
                    imgSrc === ""
                      ? "https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg"
                      : imgSrc
                  }
                  width="200"
                  height="200"
                  id="agentProfile"
                  className="img-thumbnail img-fluid"
                  onClick={() => {
                    imgSrc && showCropper(originalFile);
                  }}
                />
              </div>
            </div>
            <input
              type="file"
              className="form-control"
              onChange={onFileChange}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            <button
              className="btn btn-primary"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting && <Spinner />}
              {!isSubmitting && "Save"}
            </button>
          </div>
        </div>
      </form>
      {cropper && (
        <ImageCropper
          imgSrc={getImgSrc}
          hideCropper={hideCropper}
          setCroppedArea={setCroppedArea}
        />
      )}
    </>
  );
};
