import React from "react";
import { AgentsModel } from "../Models/AgentsModel";

export const listAgents = async ({ apiUrl }): Promise<AgentsModel[]> => {
  const res = await fetch(apiUrl);
  return res.json() as any as Promise<AgentsModel[]>;
};

export const getAgentByIdClient = async (
  detailApiUrl
): Promise<AgentsModel> => {
  const res = await fetch(detailApiUrl);
  return res.json() as any as Promise<AgentsModel>;
};

export async function addAgentClient({ addApiUrl, data }: AddAgentClientProp) {
  var formData = new FormData();
  if (data.ImageBlob) {
    formData.append("Image", data.ImageBlob, "Image.jpg");
  }

  formData.append("Name", data.name);
  formData.append("Email", data.email);
  formData.append("Mobile", data.mobile);
  formData.append("ClientId", data.clientId);
  const res = await fetch(addApiUrl, {
    method: "POST",
    body: formData,
  });
  const content = await res.json();
}

// const createImage = (url) =>
//   new Promise<CanvasImageSource>((resolve, reject) => {
//     const image = new Image();
//     image.addEventListener("load", () => resolve(image));
//     image.addEventListener("error", (error) => reject(error));
//     image.setAttribute("crossOrigin", "anonymous"); // needed to avoid cross-origin issues on CodeSandbox
//     image.src = url;
//   });

// export async function getCroppedImg(imageSrc, pixelCrop) {
//   const img =imageSrc;// await createImage(imageSrc);
//   const canvas = document.createElement("canvas");
//   canvas.width = pixelCrop.width;
//   canvas.height = pixelCrop.height;
//   const ctx = canvas.getContext("2d");

//   ctx.drawImage(
//     img,
//     pixelCrop.x,
//     pixelCrop.y,
//     pixelCrop.width,
//     pixelCrop.height,
//     0,
//     0,
//     pixelCrop.width,
//     pixelCrop.height
//   );

//   // As Base64 string
//   // return canvas.toDataURL('image/jpeg');

//   // As a blob
//   return new Promise<Blob>((resolve, reject) => {
//     canvas.toBlob((file) => {
//       resolve(file);
//     }, "image/jpeg");
//   });
// }
// export const convertFileToBase64 = (file) =>
//   new Promise((resolve, reject) => {
//     console.log(file);
//     const reader = new FileReader();
//     reader.readAsDataURL(file);

//     reader.onload = () => resolve({
//         fileName: file.title,
//         base64: reader.result
//     });
//     reader.onerror = reject;
//   });

interface AddAgentClientProp {
  addApiUrl: string;
  data: any;
}
