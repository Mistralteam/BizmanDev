import React from "react";
import ReactDOM from "react-dom";
import { ListingSearch } from "./components/ListingSearch";
import { AgentComponent } from "./components/Agents/Index";
import { AddEditAgent } from "./components/Agents/AddEditAgent";
import { Router, Link } from "@reach/router";
export class RSLib {
  public components = {
    ListingSearch,
    AgentComponent,
    AddEditAgent,
  };

  render(component: any, container: any, props: any) {
    const Comp = this.components[component];
    const Props = Object.assign({}, props);
    ReactDOM.render(
      <Comp {...Props} />,
      container
    );
  }
}

const RSLibInstance = new RSLib();
export default RSLibInstance;
