﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NEvilES.Abstractions.Pipeline;
using NEvilES.Abstractions.Pipeline.Async;
using NEvilES.Pipeline;
using NEvilES.Pipeline.Async;
using RealSoftware.Common.NEvilES;

namespace RealSoftware.Crm.Tools
{
    public abstract partial class Replay
    {
        public class App
        {
            private readonly IServiceScopeFactory _serviceScopeFactory;
            public App(IServiceScopeFactory serviceScopeFactory)
            {
                this._serviceScopeFactory = serviceScopeFactory;
            }

            public async Task Run()
            {

                using var scope = _serviceScopeFactory.CreateScope();

                var factory = scope.ServiceProvider.GetService<IFactory>();
                var reader = scope.ServiceProvider.GetService<IAsyncAggregateHistory>();
                var logger = scope.ServiceProvider.GetService<ILogger<Replay.App>>();

                var inmemoryReadModel = scope.ServiceProvider.GetService<InMemoryReadModel>();

                logger.LogInformation("Starting replay");
                await ReplayAsync(factory, reader);

                logger.LogInformation("InMemory Replay complete. Commiting to DB");

                var dynamoReadWriteModel = scope.ServiceProvider.GetService<DynamoReadWriteModel>();

                foreach (var item in inmemoryReadModel.GetAll())
                {
                    await dynamoReadWriteModel.InternalSaveAsync(item);
                }

                logger.LogInformation("InMemory Replay complete. Commiting to DB");
            }

            public static void Replay(IFactory factory, IAggregateHistory reader, Int64 from = 0, Int64 to = 0)
            {
                foreach (var commit in reader.Read(from, to))
                {
                    CommandResult commandResult = new CommandResult(commit);
                    ReadModelProjectorHelper.Project(commandResult, factory, new CommandContext(new CommandContext.User(commit.By), null, CommandContext.User.NullUser(), null));
                }
            }

            public static async Task ReplayAsync(IFactory factory, IAsyncAggregateHistory reader, Int64 from = 0, Int64 to = 0)
            {
                foreach (var commit in (await reader.ReadAsync(from, to)))
                {
                    CommandResult commandResult = new CommandResult(commit);
                    await ReadModelProjectorHelperAsync.ProjectAsync(commandResult, factory, new CommandContext(new CommandContext.User(commit.By), null, CommandContext.User.NullUser(), null));
                }
            }
        }
    }
}