using NEvilES;
using NEvilES.Abstractions;
using RealSoftware.Management.Domain.Validators;

namespace RealSoftware.Management.Domain
{
    public abstract class Agency
    {

        public class Aggregate : AggregateBase
            , IHandleAggregateCommand<Contracts.Agency.OnBoardNewAgency>//, IAgencyNameValidator>
        {

            public ICommandResponse Handle(Contracts.Agency.OnBoardNewAgency command)//, IAgencyNameValidator agencyNameValidator)
            {
                if (string.IsNullOrEmpty(command.AgencyName))
                {

                }

                // if (agencyNameValidator.Exists(command.AgencyName))
                // {
                //     throw new DomainAggregateException(this, "An agency with the name {0} already exists", command.AgencyName);
                // }



                RaiseEvent(new Contracts.Agency.OnBoardedNewAgency
                {
                    StreamId = command.StreamId,
                    AgencyName = command.AgencyName,
                    PrimaryContact = command.PrimaryContact
                });

                return new CommandCompleted(command.StreamId, "");
            }


            private void Apply(Contracts.Agency.OnBoardedNewAgency e)
            {
                Id = e.StreamId;
            }
        }
    }
}