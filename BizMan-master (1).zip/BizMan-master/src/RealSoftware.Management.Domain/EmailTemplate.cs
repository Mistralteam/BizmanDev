﻿using System;
using System.Collections.Generic;
using System.Text;
using NEvilES;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Domain
{
    public class EmailTemplate : AggregateBase
        , IHandleAggregateCommand<Contracts.EmailTemplate.AddEmailTemplate>
    {
        public ICommandResponse Handle(Contracts.EmailTemplate.AddEmailTemplate command)
        {
            RaiseEvent(new Contracts.EmailTemplate.AddedEmailTemplate()
            {
                Id = command.Id,
                Name = command.Name,
                StreamId = command.StreamId,
                Template = command.Template
            });
            return new CommandCompleted(command.StreamId, "");
        }
        private void Apply(Contracts.EmailTemplate.AddedEmailTemplate e)
        {
            Id = e.StreamId;
        }
    }
}
