using NEvilES;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Domain
{
    public abstract class Agent
    {

        public class Aggregate : AggregateBase
            , IHandleAggregateCommand<Contracts.Agent.AddAgent>
        {
            public ICommandResponse Handle(Contracts.Agent.AddAgent command)
            {
                RaiseEvent(new Contracts.Agent.AgentCreated
                {
                    StreamId = command.StreamId,
                    AgencyId = command.AgencyId,
                    Email = command.Email,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    ReaAgentId = command.ReaAgentId
                });
                return new CommandCompleted(command.StreamId, "");
            }

            private void Apply(Contracts.Agent.AgentCreated e)
            {

            }
        }
    }
}