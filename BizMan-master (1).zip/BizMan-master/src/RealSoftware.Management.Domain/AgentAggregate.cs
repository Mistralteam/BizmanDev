﻿using System;
using System.Collections.Generic;
using System.Text;
using NEvilES;
using NEvilES.Abstractions;
using RealSoftware.Management.Contracts;

namespace RealSoftware.Management.Domain
{
    class AgentAggregate: AggregateBase
        , IHandleAggregateCommand<Agents.AddAgent>
    {
        public ICommandResponse Handle(Agents.AddAgent command)
        {
            Raise<Agents.AddedAgent>(command);
            return new CommandCompleted(command.StreamId, "");
        }
        private void Apply(Contracts.Agents.AddedAgent e)
        {

        }
    }
}
