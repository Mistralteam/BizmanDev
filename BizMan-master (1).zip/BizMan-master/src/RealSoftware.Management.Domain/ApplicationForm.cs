﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using NEvilES;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Domain
{
    public class ApplicationForm: AggregateBase,
        IHandleAggregateCommand<Contracts.ApplicationForm.AddFile>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApplicationForm(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public ICommandResponse Handle(Contracts.ApplicationForm.AddFile command)
        {
            throw new NotImplementedException();
        }
    }
}
