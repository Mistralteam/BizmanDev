﻿using System;
using NEvilES;
using NEvilES.Abstractions;

namespace RealEstate.Management.Contracts
{
    public abstract class Client
    {

        public class CreateNewClientSubscription : ClientSubscriptionCreated, ICommand
        {
        }

        public class ClientSubscriptionCreated : Event
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Mobile { get; set; }
        }

        public class Aggregate : AggregateBase
        {
            
        }



    }
}
