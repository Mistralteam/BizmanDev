namespace RealSoftware.Management.Domain.Validators
{
    public interface IAgencyNameValidator
    {
        bool Exists(string agencyName);
    }
}