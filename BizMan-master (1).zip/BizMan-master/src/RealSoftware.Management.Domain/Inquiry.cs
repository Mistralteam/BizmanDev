using NEvilES;
using NEvilES.Abstractions;

namespace RealSoftware.Management.Domain
{
    public abstract class Inquiry
    {
        public class Aggregate : AggregateBase
            , IHandleAggregateCommand<Contracts.Inquiry.NewWebsiteInquiry>
        {
            public ICommandResponse Handle(Contracts.Inquiry.NewWebsiteInquiry command)
            {

                RaiseEvent(new Contracts.Inquiry.WebsiteInquiryReceived
                {
                    StreamId = command.StreamId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    Email = command.Email,
                    Phone = command.Phone,
                    Interests = command.Interests,
                    Notes = command.Notes
                });
                return new CommandCompleted(command.StreamId, "");
            }

            private void Apply(Contracts.Inquiry.WebsiteInquiryReceived e)
            {

            }
        }
    }
}