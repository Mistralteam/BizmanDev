﻿// using System;
// using System.Collections.Generic;
// using Amazon.DynamoDBv2.DataModel;
// using RealSoftware.Common.DynamoDB.Converters;

// namespace RealSoftware.Management.ReadModel
// {
//     [DynamoDBTable("clients")]
//     public class Client
//     {
//         public Guid ClientId { get; set; }
//         public string Name { get; set; }
//         public string CompanyName { get; set; }
//         public Address BillingAddress { get; set; }

//         public List<Contact> Contacts { get; set; }

//         public partial class Address
//         {
//             public string Line1 { get; set; }
//             public string Line2 { get; set; }
//             public string Suburb { get; set; }
//             public string State { get; set; }
//             public string Postcode { get; set; }
//         }

//         public class Contact
//         {
//             public Guid Id { get; set; }
//             public string FirstName { get; set; }
//             public string LastName { get; set; }
//             public string Email { get; set; }
//             public string PhoneNumber { get; set; }
//             public string MobileNumber { get; set; }

//             [DynamoDBProperty(typeof(EnumConverter<ContactType>))]
//             public ContactType Type { get; set; }
//             public string Notes { get; set; }

//         }

//         public enum ContactType
//         {
//             Primary = 0,
//             Marketing = 1,
//             Accounts = 2,
//             Other
//         }
//     }


// }
