using System;
using System.Collections.Generic;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{
    [DynamoDBTable("properties")]
    public class Property
    {
        [DynamoDBGlobalSecondaryIndexHashKey("Id-Index")]
        public Guid Id { get; set; }

        [DynamoDBRangeKey]
        public string UniqueId { get; set; }

        [DynamoDBHashKey]
        public Guid ClientId { get; set; }

        public AddressModel Address { get; set; }

        public class AddressModel
        {
            public string StreetNumber { get; set; }
            public string StreetName { get; set; }
            public string Suburb { get; set; }
            public string State { get; set; }
            public string Postcode { get; set; }
        }

        public string Heading { get; set; }
        public string Description { get; set; }
        public List<Guid> ListingAgents { get; set; }
    }
}