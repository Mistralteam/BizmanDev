using System;
using System.Collections.Generic;
using Amazon.DynamoDBv2.DataModel;
using RealSoftware.Common.DynamoDB.Converters;

namespace RealSoftware.Management.ReadModel.Forms
{
    public class FacebookApp : GenericClientFormBase
    {
        public string Name { get; set; }
        public string TradingName { get; set; }
        public string ABN { get; set; }
        public string PhoneNumber { get; set; }
        public string OfficeAddress { get; set; }
        public string OfficeWebsite { get; set; }
        public ClientReviewOptions ClientReviews { get; set; }
        public string EnquiresEmail { get; set; }
        public Contact MainContact { get; set; }

        public bool UseMainContactForAccounts { get; set; }
        public Contact Accounts { get; set; }

        [DynamoDBProperty(typeof(EnumConverter<ListingFeedProvider>))]
        public ListingFeedProvider? ListingUploader { get; set; }
        public string ListingUploaderOther { get; set; }
        public FacebookDetails Facebook { get; set; }
        public FacebookPageOwner FacebookPageOwner { get; set; }

        public FileInfo Logo { get; set; }
        public FileInfo HeroImage { get; set; }
        public FileInfo StaffContactDetails { get; set; }

        public FileInfo StaffPic1 { get; set; }
        public FileInfo StaffPic2 { get; set; }
        public FileInfo StaffPic3 { get; set; }
        public FileInfo StaffPic4 { get; set; }
        public FileInfo StaffPic5 { get; set; }


        public List<FileInfo> OtherFiles { get; set; }
    }

    public class FileInfo
    {
        public Guid FileId { get; set; }
        public string FileName { get; set; }
        public string Tag { get; set; }
    }

    public class FacebookPageOwner
    {
        // public FacebookPageOwnershipType? OwnershipType { get; set; }
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
    }


    public enum ClientReviewOptions : int
    {
        RMA = 1,
        Google = 2,
        Facebook = 3,
        ClientProvided = 4,
    }

    public class FacebookDetails
    {
        public string Url { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
    }


    public enum ListingFeedProvider
    {
        VaultRE = 1,
        MyDesktop = 2,
        Consul = 3,
        ListOnce = 4,
        AgentBox = 5,
        BoxAndDice = 6,
        Rex = 7,
        LockedOn = 8,
        Zenu = 9,
        EagleSoftware = 10,
        AgentPoint = 11,
        HarcourtsH1 = 12,
        LJHookerMove2 = 13,




        Other = 80
    }

    public class Contact
    {
        public string FirstName { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string LastName { get; set; }
    }

    public class UploadFiles
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int FileSize { get; set; }

    }
}