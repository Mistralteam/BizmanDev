﻿using System;
using System.Collections.Generic;
using System.Text;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{
    [DynamoDBTable("email-template")]
    public class EmailTemplate
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Template { get; set; }
    }
}
