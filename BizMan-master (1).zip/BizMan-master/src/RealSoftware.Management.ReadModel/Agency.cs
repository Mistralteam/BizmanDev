// using System;
// using Amazon.DynamoDBv2.DataModel;

// namespace RealSoftware.Management.ReadModel
// {
//     [DynamoDBTable("agencies")]
//     public class Agency
//     {
//         [DynamoDBHashKey]
//         public Guid Id { get; set; }

//         public string Name { get; set; }

//         [DynamoDBGlobalSecondaryIndexHashKey("ClientId-Index")]
//         public Guid ClientId { get; set; }

//     }
// }