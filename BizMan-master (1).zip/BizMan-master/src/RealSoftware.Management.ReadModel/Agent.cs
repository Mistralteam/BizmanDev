using System;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{
    [DynamoDBTable("agents")]
    public class Agent
    {
        [DynamoDBRangeKey("Id")]
        public Guid Id { get; set; }

        [DynamoDBHashKey("AgencyId")]
        public Guid AgencyId {get;set;}

        [DynamoDBGlobalSecondaryIndexHashKey("AgentId-Index")]
        public string AgentID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}