using System;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{
    [DynamoDBTable("client-forms")]
    public class ClientForms<T> where T : IClientForm
    {
        [DynamoDBHashKey]
        public Guid FormId { get; set; }

        [DynamoDBGlobalSecondaryIndexHashKey("ClientId-Index")]
        public Guid ClientId { get; set; }

        [DynamoDBProperty(typeof(Common.DynamoDB.Converters.EnumConverter<FormType>))]
        public FormType Type { get; set; }
        public T FormData { get; set; }

        [DynamoDBProperty(typeof(Common.DynamoDB.Converters.EnumConverter<FormStatus>))]
        public FormStatus Status { get; set; }

        [DynamoDBProperty(typeof(Common.DynamoDB.Converters.DateTimeOffsetConverter))]
        public DateTimeOffset? LastUpdated { get; set; }
    }

    public interface IClientForm
    {
        FormType Type { get; set; }
    }

    public class GenericClientFormBase : IClientForm
    {
        [DynamoDBProperty(typeof(Common.DynamoDB.Converters.EnumConverter<FormType>))]
        public FormType Type { get; set; }
    }

    public enum FormType
    {
        FacebookApp,
        AgentWebsite,
        CRM
    }

    public enum FormStatus
    {
        Sent = 1,
        InProgress = 2,
        Complete = 3,
    }
}