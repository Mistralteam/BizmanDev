﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{




}
//     [DynamoDBTable("facebook-client")]
//     public class FacebookClient
//     {


//         [DynamoDBHashKey]
//         public Guid ClientId { get; set; }
//         [Required(ErrorMessage ="Name is required")]
//         public string Name { get; set; }
//         [Required(ErrorMessage = "Trading Name is required")]
//         public string TradingName { get; set; }
//         [Required(ErrorMessage = "ABN is required")]
//         public string ABN { get; set;  }
//         [Required(ErrorMessage = "Phone Number is required")]
//         public string PhoneNumber { get; set; }
//         [Required(ErrorMessage = "Office Address is required")]
//         public string OfficeAddress { get; set; }
//         [Required(ErrorMessage = "Office Website is required")]
//         public string OfficeWebsite { get; set; }

//         public Contact MainContact { get; set; }
//         public Contact Accounts { get; set; }
//         public List<string> ListingUploader { get; set; }
//         public string Facebook { get; set; }
//         public string PageOwner { get; set; }
//         public Contact BusinessManager { get; set; }
//         public Contact FacebookPageOwner { get; set; }
//         public List<string> Path { get; set; }
//     }

//     public class Contact
//     {
//         public string Name { get; set; }
//         public string MobileNumber { get; set; }
//         public string Email { get; set; }
//     }

//     public class Reviews
//     {

//     }

//     public class UploadFiles
//     {
//         public string Name { get; set; }
//         public string Image { get; set; }
//         public int FileSize { get; set; }
//         public string Id { get; set; }
//         public byte[] File { get; set; }
//     }
// }
