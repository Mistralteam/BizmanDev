using System;
using Amazon.DynamoDBv2.DataModel;

namespace RealSoftware.Management.ReadModel
{
    [DynamoDBTable("feed-files")]
    public class FeedFile
    {
        [DynamoDBRangeKey]
        [DynamoDBGlobalSecondaryIndexRangeKey("Id-Index")]
        public Guid Id { get; set; }

        [DynamoDBHashKey]
        [DynamoDBGlobalSecondaryIndexRangeKey("FileName-ClientId-Index")]
        public Guid ClientId { get; set; }

        [DynamoDBGlobalSecondaryIndexHashKey("FileName-ClientId-Index")]
        public string FileName { get; set; }
        public Guid UploadedByUserId { get; set; }
        public string UploadedByUser { get; set; }
        public DateTimeOffset UploadedAt { get; set; }
        public string StorageObjectKey { get; set; }

    }
}