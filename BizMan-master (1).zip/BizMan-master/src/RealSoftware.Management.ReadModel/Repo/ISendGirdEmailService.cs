﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace RealSoftware.Management.ReadModel.Repo
{
    public interface ISendGirdEmailService
    {
        Task<Response> SendEmail(EmailAddress from,
            string subject,
            string htmlContent,
            string textContent,
            EmailAddress to,
            List<EmailAddress> cc = null,
            List<EmailAddress> bcc = null);
    }

    public class SendGirdEmailService : ISendGirdEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<SendGirdEmailService> _logger;

        public SendGirdEmailService(IConfiguration configuration)
        {
            _configuration = configuration;

        }
        public async Task<Response> SendEmail(EmailAddress @from, string subject, string htmlContent, string textContent, EmailAddress to, List<EmailAddress> cc = null,
            List<EmailAddress> bcc = null)
        {

            if (string.IsNullOrEmpty(_configuration["SendGrid:ApiKey"]))
            {
                throw new System.Exception("SendGrid API Key is not configured");
            }

            Console.WriteLine("Sending email from {0} to {1}", from, to);

            var apiKey = _configuration["SendGrid:ApiKey"];
            var client = new SendGridClient(apiKey);
            var msg = MailHelper.CreateSingleEmail(from, to,
                subject,
                textContent,
                htmlContent);




           

            if (cc != null)
            {
                msg.AddCcs(cc);
            }

            if (bcc != null)
            {
                msg.AddBccs(bcc);
            }

            return await client.SendEmailAsync(msg);
        }
    }
}
