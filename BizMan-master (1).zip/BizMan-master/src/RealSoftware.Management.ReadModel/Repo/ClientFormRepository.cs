using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;

namespace RealSoftware.Management.ReadModel.Repo
{
    public class ClientFormRepository
    {
        private readonly IDynamoDBContext _dynamoDBContext;

        public ClientFormRepository(IDynamoDBContext dynamoDBContext)
        {
            _dynamoDBContext = dynamoDBContext;
        }

        public Task<ClientForms<T>> GetAsync<T>(Guid formId) where T : IClientForm
        {

            return _dynamoDBContext.LoadAsync<ClientForms<T>>(formId);

        }

        // public Task<ClientForms<T>> GetAsync<T>(Guid formId, Guid clientId) where T : IClientForm
        // {

        //     return _dynamoDBContext.LoadAsync<ClientForms<T>>(formId, clientId);
        //     // return form;
        // }

        public Task<List<ClientForms<T>>> GetAllForClient<T>(Guid clientId) where T : IClientForm
        {

            var search = _dynamoDBContext.FromQueryAsync<ClientForms<T>>(new QueryOperationConfig
            {

                IndexName = "ClientId-Index",
                KeyExpression = new Expression
                {
                    ExpressionStatement = "ClientId = :clientId",
                    ExpressionAttributeValues = new Dictionary<string, DynamoDBEntry>
                    {
                        {":clientId", clientId },
                    }
                },
                ConsistentRead = false,
                // Limit = limit
            });

            return search.GetRemainingAsync();
        }

        public async Task CreateAysnc<T>(ClientForms<T> clientForm) where T : IClientForm
        {
            var form = await GetAsync<T>(clientForm.FormId);

            if (form != null)
            {
                throw new Exception("Form already exists");
            }


            await _dynamoDBContext.SaveAsync(clientForm);
        }

        public async Task SaveAsync<T>(ClientForms<T> clientForm, DateTimeOffset? currentVersionTimestamp) where T : IClientForm
        {
            var form = await GetAsync<T>(clientForm.FormId);

            if (form.LastUpdated.HasValue && currentVersionTimestamp.HasValue && form.LastUpdated.Value.ToString() != currentVersionTimestamp.Value.ToString())
            {
                throw new DataMisalignedException("The version of the form that was updated was out of date.");
            }

            clientForm.LastUpdated = DateTimeOffset.Now;

            await _dynamoDBContext.SaveAsync(clientForm);
        }

        // public async Task UpdateFormMeta(ClientForms clientForm, DateTimeOffset? currentVersionTimestamp)
        // {
        //     // var form = await GetAsync<GenericClientFormBase>(clientForm.FormId);

        //     _dynamoDBContext.FromDocument

        //     if (form.LastUpdated.HasValue && currentVersionTimestamp.HasValue && form.LastUpdated.Value.ToString() != currentVersionTimestamp.Value.ToString())
        //     {
        //         throw new DataMisalignedException("The version of the form that was updated was out of date.");
        //     }

        //     clientForm.LastUpdated = DateTimeOffset.Now;





        // }
    }
}