using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;

namespace RealSoftware.Management.ReadModel.Repo
{
    public class ClientMediaRepo
    {
        private readonly IDynamoDBContext _db;

        public ClientMediaRepo(IDynamoDBContext db)
        {
            _db = db;
        }

        public async Task<ClientMedia> Get(Guid fileId, CancellationToken cts = default)
        {
            if (fileId == null || fileId == Guid.Empty)
            {
                throw new NullReferenceException(nameof(fileId));
            }



            var res = await _db.FromQueryAsync<ClientMedia>(new QueryOperationConfig
            {
                KeyExpression = new Expression
                {
                    ExpressionStatement = "FileId=:id",
                    ExpressionAttributeValues = new Dictionary<string, DynamoDBEntry>{
                        {":id",fileId}
                    }
                }

            }).GetRemainingAsync();

            return res.FirstOrDefault();
        }

        public Task Create(ClientMedia media, CancellationToken cts = default)
        {
            if (media == null)
            {
                throw new NullReferenceException(nameof(ClientMedia));
            }

            return _db.SaveAsync(media, cts);
        }

        public async Task<List<ClientMedia>> List(Guid clientId, CancellationToken cts = default)
        {
            if (clientId == null || clientId == Guid.Empty)
            {
                throw new NullReferenceException(nameof(clientId));
            }


            var search = _db.FromQueryAsync<ClientMedia>(new QueryOperationConfig
            {
                IndexName = "ClientId-Index",
                KeyExpression = new Expression
                {

                    ExpressionStatement = "ClientId = :clientId",
                    ExpressionAttributeValues = new Dictionary<string, DynamoDBEntry>
                    {
                        {":clientId", clientId },
                    }
                },
                ConsistentRead = false,
                // Limit = 50
            });

            return await search.GetNextSetAsync(cts);
        }


        public Task Delete(ClientMedia media, CancellationToken cts = default)
        {
            if (media == null)
            {
                throw new NullReferenceException(nameof(ClientMedia));
            }


            return _db.DeleteAsync(media, cts);
        }


        public async Task<List<ClientMedia>> GetByClientId(string clientId)
        {

            if (string.IsNullOrEmpty(clientId))
            {
                throw new NullReferenceException(nameof(clientId));
            }



            var res = await _db.FromQueryAsync<ClientMedia>(new QueryOperationConfig
            {
                IndexName = "ClientId-Index",
                KeyExpression = new Expression
                {
                    ExpressionStatement = "ClientId=:id",
                    ExpressionAttributeValues = new Dictionary<string, DynamoDBEntry>{
                        {":id",clientId}
                    }
                }

            }).GetRemainingAsync();

            return res;
        }
    }

   
}