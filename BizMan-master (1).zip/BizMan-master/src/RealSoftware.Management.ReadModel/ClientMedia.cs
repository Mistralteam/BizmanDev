using System;
using System.Collections.Generic;
using Amazon.DynamoDBv2.DataModel;
using NEvilES.DataStore.DynamoDB.Converters;

namespace RealSoftware.Management.ReadModel
{



    [DynamoDBTable("client-media")]
    public class ClientMedia
    {
        [DynamoDBHashKey]
        public Guid FileId { get; set; }

        [DynamoDBRangeKey]
        [DynamoDBGlobalSecondaryIndexHashKey("ClientId-Index")]
        public Guid ClientId { get; set; }
        public string FileName { get; set; }
        public string FileKey { get; set; }
        public List<string> Tags { get; set; }
        public Dictionary<string, string> Meatdata { get; set; }

        [DynamoDBProperty(typeof(DateTimeOffsetConverter))]
        public DateTimeOffset UploadedAt { get; set; }
        public string ContentType { get; set; }
        public long Size { get; set; }
    }
}