using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Amazon;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
// using RepoDb;
using System.Reflection;
using System;
using RealSoftware.Common.Implementation.Amazon.Extensions;

namespace RealSoftware.Management.Common
{

    public static class SharedServiceCollectionExtensions
    {
        public static IServiceCollection AddSharedServices(this IServiceCollection services, IConfiguration Configuration)
        {
            // Converter.ConversionType = RepoDb.Enumerations.ConversionType.Automatic;
            // RepoDb.MySqlConnectorBootstrap.Initialize();

            // services.AddSingleton<DbSettings>(s => new DbSettings
            // {
            //     ConnectionString = Configuration.GetConnectionString("Default")
            // });

            // FluentMapper
            //     .Entity<ReadModel.QueryModels.Contact>()
            //     .Table("contact");

            // FluentMapper
            //     .Entity<ReadModel.QueryModels.Appraisal>()
            //     .Table("appraisal");

            // services.AddScoped<MySqlConnection>(s => new MySqlConnection(s.GetService<DbSettings>().ConnectionString));

            services.AddDynamoDB(Configuration);

            return services;
        }
    }
}