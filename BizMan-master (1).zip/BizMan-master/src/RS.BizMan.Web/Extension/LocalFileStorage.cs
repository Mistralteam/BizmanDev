using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RealSoftware.Common.Abstractions;

namespace RealSoftware.Management.FacebookApp.Extension
{
    public class LocalFileStoreOptions
    {
        public string FileStorageBase { get; set; }
        // public string BucketName { get; set; }
    }

    public class LocalFileStorage : IFileStorage
    {
        private readonly IOptions<LocalFileStoreOptions> _options;

        public LocalFileStorage(IOptions<LocalFileStoreOptions> options)
        {
            _options = options;
        }

        public async Task<Stream> GetFileStream(string bucketName, string fileStorageKey)
        {
            string path = Path.Combine(_options.Value.FileStorageBase, bucketName, fileStorageKey);

            if (!File.Exists(path)) return null;

            return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        }

        public async Task<Stream> GetFileStream(FileDetails fileDetails)
        {
            string path = Path.Combine(_options.Value.FileStorageBase, fileDetails.BucketName, fileDetails.FileStorageKey);

            if (!File.Exists(path)) return null;

            return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        }

        public Task<FileDetails> GetFileDetails(string bucketName, string fileStorageKey)
        {
            string path = Path.Combine(_options.Value.FileStorageBase, bucketName, fileStorageKey);

            if (!File.Exists(path)) return null;

            var metaPath = GetMetaPath(path);
            var metadata = JsonConvert.DeserializeObject<Dictionary<string, string>>(File.ReadAllText(metaPath));

            return Task.FromResult(new FileDetails
            {
                BucketName = bucketName,
                FileStorageKey = fileStorageKey,
                Metadata = metadata
            });
        }

        public Task<bool> MoveFile(FileDetails file, string toFileStorageKey, string toBucket)
        {
            throw new System.NotImplementedException();
        }

        public Task<bool> MoveFile(string fromBucket, string fromFileStorageKey, string toFileStorageKey, string toBucket)
        {
            throw new System.NotImplementedException();
        }

        public Task SaveFileFromFile(string filePath, string bucketName, string fileStorageKey, Dictionary<string, string> metadata)
        {
            using var fs = new FileStream(filePath, FileMode.Open);
            return SaveFile(fs, bucketName, fileStorageKey, metadata);
        }

        public Task SaveFile(Stream fileStream, string bucketName, string fileStorageKey)
            => SaveFile(fileStream, bucketName, fileStorageKey, null);

        public Task SaveFile(Stream fileStream, string bucketName, string fileStorageKey, Dictionary<string, string> metadata)
        {
            EnsureBucketExists(bucketName);


            string path = Path.Combine(_options.Value.FileStorageBase, bucketName, fileStorageKey);

            if (File.Exists(path))
            {
                File.Delete(path);
                // throw new Exception("File Exists");
            }

            var fileDetails = new FileDetails
            {
                BucketName = bucketName,
                FileStorageKey = fileStorageKey,
                Metadata = metadata
            };

            using (var fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                fileStream.CopyTo(fs);
            }

            var metaPath = GetMetaPath(path);

            File.WriteAllText(metaPath, JsonConvert.SerializeObject(metadata));

            return Task.CompletedTask;
        }

        private void EnsureBucketExists(string bucketName)
        {
            Directory.CreateDirectory(Path.Combine(_options.Value.FileStorageBase, bucketName));
        }

        private string GetMetaPath(string path)
        {
            var ext = Path.GetExtension(path) ?? "";


            string metapath = ext.Length > 0 ? path.Replace(ext, "") + ".meta.json"  : path + ".meta.json";

            return metapath;
        }
    }
}