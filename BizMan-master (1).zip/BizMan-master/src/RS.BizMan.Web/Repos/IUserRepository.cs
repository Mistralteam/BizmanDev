using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using RealSoftware.FtpServer.ReadModel;

namespace RealSoftware.Management.FacebookApp.Web.Repos
{
    public class UserRepository : IUserRepository
    {
        private readonly IDynamoDBContext _dynamoDBContext;

        public UserRepository(IDynamoDBContext dynamoDBContext)
        {
            _dynamoDBContext = dynamoDBContext;
        }

        public async Task<List<FTPUser>> GetAllByClientId(Guid clientId)
        {
            ScanFilter scanFilter = new ScanFilter();
            scanFilter.AddCondition(nameof(FTPUser.ClientId), ScanOperator.Equal, clientId);

            var req = _dynamoDBContext.FromScanAsync<FTPUser>(new ScanOperationConfig
            {
                Filter = scanFilter
            });

            return await req.GetRemainingAsync();
        }

        public Task Save(FTPUser user)
        {
            return _dynamoDBContext.SaveAsync(user);
        }
    }

    public interface IUserRepository
    {
        Task<List<FTPUser>> GetAllByClientId(Guid clientId);
        Task Save(FTPUser user);
    }
}