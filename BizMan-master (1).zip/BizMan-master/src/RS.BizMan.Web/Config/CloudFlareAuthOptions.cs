namespace RealSoftware.Management.FacebookApp.Web.Config
{
    public class CloudFlareAuthOptions
    {
        public const string Name = "CloudFlare";

        public string AccountEmail { get; set; }
        public string ApiKey { get; set; }
        public string Token { get; set; }

        public string ZoneId { get; set; }
    }
}