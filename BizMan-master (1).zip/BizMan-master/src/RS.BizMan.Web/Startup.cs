using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Extensions.NETCore.Setup;
using Amazon.S3;
using Amazon.SQS;
using CloudFlare.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using RealSoftware.Common.Implementation.Amazon.Extensions;
using RealSoftware.Common.Abstractions;
using RealSoftware.Common.Implementation.Amazon;
using RealSoftware.FtpServer.ReadModel.Repos;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.Config;
using RealSoftware.Management.FacebookApp.Web.Repos;
using NEvilES.DataStore.DynamoDB;
using RealSoftware.Management.FacebookApp.Web.Extensions;
using Microsoft.AspNetCore.Http.Features;
using NEvilES.Abstractions.Pipeline.Async;
using RealSoftware.Common.NEvilES;
using RealSoftware.Listing.ReadModels.Repository;
using RealSoftware.Management.Common;
using Refit;
using RealSoftware.Management.FacebookApp.Web.ApiClients;
using Microsoft.AspNetCore.HttpOverrides;
using RealSoftware.Management.FacebookApp.Extension;
using RealSoftware.Management.ReadModel.Repo;
using Newtonsoft.Json.Converters;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using RealSoftware.Management.Facebook.WebApp.Controllers.Public;
using RealSoftware.Management.FacebookApp.Validators;
using System.IO;

namespace RS.BizMan.Web
{
    public class Startup
    {
        private readonly IWebHostEnvironment _env;

        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;
            this._env = env;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddMvc()
                .ConfigureApiBehaviorOptions(options =>
                {
                    //options.SuppressModelStateInvalidFilter = true;
                    options.InvalidModelStateResponseFactory = actionContext =>
                    {
                        var modelState = actionContext.ModelState;

                        var errors = modelState.ToDictionary(
                           kvp => string.Join('.', kvp.Key.Split('.').Select(k => System.Text.Json.JsonNamingPolicy.CamelCase.ConvertName(k))),
                           kvp => kvp.Value.Errors.Select(x => x.ErrorMessage).ToArray()
                       );

                        return new BadRequestObjectResult(errors);
                    };
                });

            services.AddDynamoDB(Configuration);
            services.AddAWSService<IAmazonSQS>();
            services.AddAWSService<IAmazonS3>();


            services.Configure<ClientMediaOptions>(Configuration.GetSection("ClientMediaOptions"));

            services.AddSingleton<ClientFormRepository>();
            services.AddSingleton<ClientMediaRepo>();
            services.AddScoped<IListingRepository, ListingRepository>();
            services.AddSingleton<IValidator<RealSoftware.Management.ReadModel.Forms.FacebookApp>, FacebookAppFormValidator>();


            // services.AddScoped<IFacebookClientRepo, FacebookClientRepo>();



            services.Configure<CloudFlareAuthOptions>(Configuration.GetSection(CloudFlareAuthOptions.Name));
            services.AddScoped<ICloudFlareClient>(s =>
            {
                return new CloudFlareClient(s.GetService<IOptions<CloudFlareAuthOptions>>().Value.Token);
            });
            var prefix = Configuration.GetValue<string>("DynamoDbSettings:TablePrefix") ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(prefix))
            {

                TableConstants.EVENT_TABLE_NAME = prefix + TableConstants.EVENT_TABLE_NAME;
            }

            if (Configuration.GetValue<string>("FileStorage") == "Local")
            {
                Console.WriteLine("Path: {0}", Path.Join(_env.WebRootPath, "buckets"));
                services.Configure<LocalFileStoreOptions>(x =>
                {
                    x.FileStorageBase = Path.Join(_env.WebRootPath, "buckets");
                    // x.BucketName = "ClientForms";
                });
                services.AddSingleton<IFileStorage, LocalFileStorage>();
            }
            else if (Configuration.GetValue<string>("FileStorage") == "S3")
            {
                services.AddSingleton<IFileStorage, S3FileStorage>();
            }

            services.AddSingleton<IQueueTask, SQSQueue>();

            services.AddScoped<IAgentRepository, AgentRepository>();
            services.AddScoped<IAgencyOfficeRepository, AgencyOfficeRepository>();
            services.AddScoped<IListingRepository, ListingRepository>();
            services.AddScoped<ITenantRepository, TenantRepository>();
            services.AddScoped<IBrandingRepository, BrandingRepository>();
            services.AddScoped<IClientRepository, ClientRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IFeedFileRepository, FeedFileRepository>();
            services.AddScoped<IFeedAgentMapRepository, FeedAgentMapRepository>();
            services.AddScoped<IHarcourtFeedsRepository, HarcourtFeedsRepository>();
            services.AddScoped<FacebookPageRepository>();

            services.AddSingleton<ISendGirdEmailService, SendGirdEmailService>();


            services.AddRefitClient<IPortalUserApi>()
                .ConfigureHttpClient(c =>
                {
                    c.BaseAddress = new Uri(Configuration["PortalApi:Url"]);
                    c.DefaultRequestHeaders.Add("X-Token", Configuration["PortalApi:Token"]);
                });

            services.AddRefitClient<IPortalClientApi>()
                .ConfigureHttpClient(c =>
                {
                    c.BaseAddress = new Uri(Configuration["PortalApi:Url"]);
                    c.DefaultRequestHeaders.Add("X-Token", Configuration["PortalApi:Token"]);
                });

            services.AddAuth0Authorization(Configuration);
            services.Configure<FormOptions>(x =>
            {
                x.MultipartBodyLengthLimit = int.MaxValue;
                x.MultipartBoundaryLengthLimit = int.MaxValue;
                x.MultipartHeadersCountLimit = int.MaxValue;
                x.MultipartHeadersLengthLimit = int.MaxValue;
            });

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });

            services.AddCors();
            services.AddControllers().AddNewtonsoftJson(opts =>
            {
                opts.SerializerSettings.Converters.Add(new StringEnumConverter());
                opts.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                opts.SerializerSettings.DefaultValueHandling = Newtonsoft.Json.DefaultValueHandling.IgnoreAndPopulate;
            });
            services
                .AddRazorPages()
                .AddRazorPagesOptions(opts =>
                {
                    opts.Conventions.AuthorizePage("/Index");
                    opts.Conventions.AuthorizeFolder("/Tenants");
                    opts.Conventions.AuthorizeFolder("/FtpAccounts");
                    opts.Conventions.AuthorizeFolder("/Feed");
                    opts.Conventions.AuthorizeFolder("/Clients");
                    // opts.Conventions.AuthorizeFolder("/Branding");
                    opts.Conventions.AuthorizeFolder("/Agents");
                    opts.Conventions.AuthorizeFolder("/Users");
                    opts.Conventions.AuthorizeFolder("/Harcourts");
                    opts.Conventions.AddPageRoute("/Feed/View", "Feed/File/{FileId}");

                    opts.Conventions.AddPageRoute("/Clients/Branding/Edit", "Clients/{ClientId}/Branding");
                    opts.Conventions.AddPageRoute("/Clients/Agents/Index", "Clients/{ClientId}/Agents");
                    opts.Conventions.AddPageRoute("/Clients/Agents/Edit", "Clients/{ClientId}/Agent/{AgentId?}");
                    // opts.Conventions.AddPageRoute("/Clients/Branding/Index", "Clients/{ClientId}/Branding");
                    opts.Conventions.AddPageRoute("/Clients/Media/Index", "Clients/{ClientId}/Media");
                    opts.Conventions.AddPageRoute("/Clients/Forms/Index", "Clients/{ClientId}/Forms");
                    opts.Conventions.AddPageRoute("/Clients/Forms/View", "Clients/{ClientId}/Form/{FormId}");
                    opts.Conventions.AddPageRoute("/Clients/Listings/Index", "Clients/{ClientId}/Listings");
                });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsEnvironment("Development") || env.IsEnvironment("Local"))
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseCookiePolicy();
            app.UseForwardedHeaders();

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseCors(opt => opt
               .AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader()
           );

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Contact}/{action=Index}");
                endpoints.MapRazorPages();
            });
        }
    }
}
