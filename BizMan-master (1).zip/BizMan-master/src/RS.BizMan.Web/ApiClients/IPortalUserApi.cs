using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Refit;

namespace RealSoftware.Management.FacebookApp.Web.ApiClients
{
    public interface IPortalUserApi
    {
        [Get("/internal-api/user/GetUsersForClientId")]
        Task<ApiResponse<GetClientUsersResponse>> GetUsersForClient([Query("id")] Guid clientId);

        [Post("/internal-api/user")]
        Task<ApiResponse<CreateUserResponse>> CreateNewUser([Body] CreateUserRequest model);

        [Post("/internal-api/user/{model.UserId}/delete")]
        Task<ApiResponse<DeleteUserReponse>> DeleteUser([Body] DeleteUserRequest model);
    }


    public class DeleteUserRequest
    {
        public Guid ClientId { get; set; }
        public Guid UserId { get; set; }
    }

    public class DeleteUserReponse
    {
        public bool Deleted { get; set; }
    }



    public class GetClientUsersResponse
    {

        public List<User> Users { get; set; }
    }

    public class User
    {
        public Guid Id { get; set; }
        public Guid ClientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }



    public class CreateUserRequest
    {
        public Guid UserId { get; set; }
        public Guid ClientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class CreateUserResponse
    {
        public Guid Id { get; set; }
        public bool Created { get; set; }
    }
}