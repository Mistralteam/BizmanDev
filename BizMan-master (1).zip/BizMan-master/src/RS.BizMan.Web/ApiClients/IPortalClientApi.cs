using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Refit;

namespace RealSoftware.Management.FacebookApp.Web.ApiClients
{
    public interface IPortalClientApi
    {
        [Get("/internal-api/client/{clientId}")]
        Task<ApiResponse<GetClientResponse>> GetClient(Guid clientId);

        [Post("/internal-api/client")]
        Task CreateClient([Body] CreateClientRequest model);

        [Post("/internal-api/client/products")]
        Task AddProduct([Body] AddClientProductRequest model);

        // [Delete("/internal-api/user/{model.UserId}")]
        // Task<ApiResponse<DeleteUserReponse>> DeleteUser([Body] DeleteUserRequest model);
    }

    public class AddClientProductRequest
    {
        public Guid ClientId { get; set; }
        public string ProductName { get; set; }
    }


    public class CreateClientRequest
    {
        public Guid ClientId { get; set; }

        public string Name { get; set; }
        public string CompanyName { get; set; }

        public List<Contact> Contacts { get; set; }

        public class Contact
        {
            public Guid? Id { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public ContactType? Type { get; set; }

        }

    }

    public class Address
    {
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Suburb { get; set; }
        public string Postcode { get; set; }
        public string State { get; set; }
    }

    public enum ContactType
    {
        Primary = 1,
        Marketing = 2,
        Accounts = 3
    }

    public class GetClientResponse
    {
        public Guid Id { get; set; }
        public string? CompanyName { get; set; }
        public List<string>? Products { get; set; }
    }
}