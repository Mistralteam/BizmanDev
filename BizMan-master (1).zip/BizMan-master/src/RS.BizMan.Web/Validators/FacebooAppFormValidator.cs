using FluentValidation;
using FluentValidation.Validators;
using RealSoftware.Management.FacebookApp.Models;
using RealSoftware.Management.ReadModel.Forms;

namespace RealSoftware.Management.FacebookApp.Validators
{
    public class FacebookAppFormValidator : AbstractValidator<ReadModel.Forms.FacebookApp>
    {
        public FacebookAppFormValidator()
        {
            RuleFor(x => x.Name).NotEmpty();
            RuleFor(x => x.TradingName).NotEmpty();
            RuleFor(x => x.ABN).NotEmpty();
            RuleFor(x => x.PhoneNumber).NotEmpty();
            RuleFor(x => x.OfficeAddress).NotEmpty();
            RuleFor(x => x.OfficeWebsite).NotEmpty();

            RuleFor(x => x.ClientReviews).NotEmpty().IsInEnum();

            RuleFor(x => x.MainContact).SetValidator(new ContactValidator());
            When(x => x.UseMainContactForAccounts == false, () =>
             {
                 RuleFor(x => x.Accounts)
                     .SetValidator(new ContactValidator());
             });

            RuleFor(x => x.Facebook).SetValidator(new FacebookDetailsValidator());
            RuleFor(x => x.FacebookPageOwner).SetValidator(new FacebookPageOwnerValidator());

            RuleFor(x => x.ListingUploader).NotEmpty().IsInEnum();

            When(x => x.ListingUploader == ReadModel.Forms.ListingFeedProvider.Other, () =>
            {
                RuleFor(x => x.ListingUploaderOther).NotEmpty();
            });

            RuleFor(x => x.EnquiresEmail).EmailAddress().NotEmpty();

            RuleFor(x => x.HeroImage).NotEmpty().WithName("Hero Image").SetValidator(new MediaInfoValidator());
            // RuleFor(x => x.HeroImage).SetValidator(new MediaInfoValidator());

            RuleFor(x => x.Logo).NotEmpty().WithName("Logo");
            RuleFor(x => x.Logo).SetValidator(new MediaInfoValidator());

            RuleFor(x => x.StaffContactDetails).NotEmpty().WithName("Staff Contact Details").SetValidator(new MediaInfoValidator());

            RuleFor(x => x.StaffPic1).NotEmpty().WithName("Staff 1 Profile Pic");
            RuleFor(x => x.StaffPic1).SetValidator(new MediaInfoValidator());

            // RuleFor(x => x.StaffPic2).NotEmpty().WithName("Staff 2 Profile Pic");
            // RuleFor(x => x.StaffPic2).SetValidator(new MediaInfoValidator());

            // RuleFor(x => x.StaffPic3).NotEmpty().WithName("Staff 3 Profile Pic");
            // RuleFor(x => x.StaffPic3).SetValidator(new MediaInfoValidator());

            // RuleFor(x => x.StaffPic4).NotEmpty().WithName("Staff 4 Profile Pic");
            // RuleFor(x => x.StaffPic4).SetValidator(new MediaInfoValidator());

            // RuleFor(x => x.StaffPic5).NotEmpty().WithName("Staff 5 Profile Pic");
            // RuleFor(x => x.StaffPic5).SetValidator(new MediaInfoValidator());


        }
    }

    public class MediaInfoValidator : AbstractValidator<FileInfo>
    {
        public MediaInfoValidator()
        {
            RuleFor(x => x.FileName).NotEmpty();
            RuleFor(x => x.FileName).Length(1, 250);
            // RuleFor(x => x.FileName).Must(FileNameIsValid);
            RuleFor(x => x.FileId).NotEmpty();
            RuleFor(x => x.Tag).NotEmpty();

        }
    }

    public class FacebookDetailsValidator : AbstractValidator<ReadModel.Forms.FacebookDetails>
    {
        public FacebookDetailsValidator()
        {
            RuleFor(x => x.Id).NotEmpty();
            RuleFor(x => x.Name).NotEmpty().WithName("Page Owner Name");
            RuleFor(x => x.Url).NotEmpty();
        }
    }

    public class ContactValidator : AbstractValidator<ReadModel.Forms.Contact>
    {
        public ContactValidator()
        {
            RuleFor(x => x.FirstName).NotEmpty();
            RuleFor(x => x.LastName).NotEmpty();
            RuleFor(x => x.MobileNumber).NotEmpty();
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
        }
    }
    public class FacebookPageOwnerValidator : AbstractValidator<ReadModel.Forms.FacebookPageOwner>
    {
        public FacebookPageOwnerValidator()
        {
            // RuleFor(x => x.OwnershipType).NotEmpty().IsInEnum();
            RuleFor(x => x.Name).NotEmpty();
            RuleFor(x => x.MobileNumber).NotEmpty();
            RuleFor(x => x.Email).NotEmpty().EmailAddress();

        }
    }

}