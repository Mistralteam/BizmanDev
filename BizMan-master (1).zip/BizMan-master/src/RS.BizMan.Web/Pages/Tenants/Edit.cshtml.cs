using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CloudFlare.Client;
using CloudFlare.Client.Enumerators;
using CloudFlare.Client.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.Config;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Tenants
{
    public class EditModel : PageModel
    {
        private const string CLIENT_DOMAIN = ".realsft.net";
        private readonly ITenantRepository _tenantRepository;
        private readonly ICloudFlareClient _cloudFlareClient;
        private readonly IOptions<CloudFlareAuthOptions> _cloudFlareOptions;
        private readonly IConfiguration _config;
        private readonly ILogger<IndexModel> _logger;

        public EditModel(
            ITenantRepository tenantRepository,
            ICloudFlareClient cloudFlareClient,
            IOptions<CloudFlareAuthOptions> cloudFlareOptions,
            IConfiguration config,
            ILogger<IndexModel> logger
        )
        {
            _tenantRepository = tenantRepository;
            _cloudFlareClient = cloudFlareClient;
            _cloudFlareOptions = cloudFlareOptions;
            this._config = config;
            _logger = logger;
        }

        [BindProperty]
        public Listing.ReadModels.Tenant Tenant { get; set; }

        [Required]
        [BindProperty(SupportsGet = true)]
        public string SubDomain { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        public async Task OnGetAsync()
        {
            if (ClientId.HasValue)
            {
                var domain = "";

                if (!string.IsNullOrEmpty(SubDomain))
                {
                    domain = GetDomain();
                    Tenant = await _tenantRepository.GetAsync(ClientId.Value, domain.ToUpperInvariant());
                }

                return;
            }

            Tenant = new Listing.ReadModels.Tenant()
            {
                Domain = ""
            };
        }

        public async Task<IActionResult> OnPostAsync()
        {

            string tenantDomain = GetDomain();




            try
            {
                var zonesQueryResult = await _cloudFlareClient.GetZoneDetailsAsync(_cloudFlareOptions.Value.ZoneId);
                // var dns = await _cloudFlareClient.GetDnsRecordsAsync(zonesQueryResult.Result.Id);
                var details = await _cloudFlareClient.GetDnsRecordDetailsAsync(zonesQueryResult.Result.Id, tenantDomain);

                if (details.Success)
                {
                    ModelState.AddModelError(nameof(SubDomain), "This subdomain already exists.");
                    return Page();
                }

                var x = await _cloudFlareClient.CreateDnsRecordAsync(_cloudFlareOptions.Value.ZoneId, DnsRecordType.Cname, tenantDomain, _config["FacebookAppDomain"], null, null, true);

                // "prdballarat.realsft.net"
                // "dev-fbsites.realsoftware.workers.dev"
            }
            catch (PersistenceUnavailableException ex)
            {

                var b = "";
            }




            if (Tenant.TenantId == Guid.Empty)
            {
                Tenant.TenantId = ClientId.Value;
            }

            Tenant.Domain = tenantDomain;
            Tenant.NormalizedDomain = Tenant.Domain.ToUpperInvariant();

            await _tenantRepository.SaveAsync(Tenant);

            return RedirectToPage(new { ClientId = Tenant.TenantId, SubDomain = Tenant.NormalizedDomain });
        }

        private string GetDomain()
        {
            if (SubDomain.EndsWith(CLIENT_DOMAIN, ignoreCase: true, CultureInfo.InvariantCulture)) return SubDomain;

            return SubDomain + CLIENT_DOMAIN;
        }
    }
}
