using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Tenants
{
    public class IndexModel : PageModel
    {
        private readonly ITenantRepository _tenantRepository;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            ITenantRepository clientRepository,
            ILogger<IndexModel> logger
        )
        {
            _tenantRepository = clientRepository;
            _logger = logger;
        }

        public List<Listing.ReadModels.Tenant> Tenants { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        public Client Client { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {

            if (!ClientId.HasValue)
            {
                return RedirectToPage("../Clients/Index");
            }

            Tenants = await _tenantRepository.GetAllByClientIdAsync(ClientId.Value);

            return Page();
        }
    }
}
