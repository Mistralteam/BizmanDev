using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.FtpServer.ReadModel.Repos;
using RealSoftware.FtpServer.ReadModel;
using RealSoftware.Common.Abstractions;
using System.IO;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Feed
{
    public class ViewModel : PageModel
    {
        private readonly IFeedFileRepository _feedFileRepository;
        private readonly IFileStorage _fileSotrage;
        private readonly ILogger<IndexModel> _logger;

        public ViewModel(
            IFeedFileRepository feedFileRepository,
            IFileStorage fileSotrage,
            ILogger<IndexModel> logger
        )
        {
            _feedFileRepository = feedFileRepository;
            _fileSotrage = fileSotrage;
            _logger = logger;
        }

        [BindProperty(SupportsGet = true)]
        public Guid FileId { get; set; }

        public FeedFile FeedFileInfo { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (FileId == Guid.Empty)
                return RedirectToPage("./Index");

            FeedFileInfo = await _feedFileRepository.GetByFileId(FileId);

            if (FeedFileInfo == null)
                return RedirectToPage("./Index");

            return Page();
        }

        public async Task<IActionResult> OnGetDownloadFileAsync()
        {
            FeedFileInfo = await _feedFileRepository.GetByFileId(FileId);

            using (var a = await _fileSotrage.GetFileStream("prod-reafeed-ftp", FeedFileInfo.GetFileKey()))
            using (MemoryStream ms = new MemoryStream())
            {
                a.CopyTo(ms);
                return File(ms.ToArray(), "application/xml", FeedFileInfo.OriginalFileName);
            }

        }

        public async Task<IActionResult> OnPostAllowReprocessAsync()
        {
            FeedFileInfo = await _feedFileRepository.GetByFileId(FileId);

            if (FeedFileInfo == null || FeedFileInfo.Status.HasValue && FeedFileInfo.Status.Value == FileStatus.Processed)
            {
                return RedirectToPage("./View", new { FileId });
            }

            FeedFileInfo.AllowReprocess = true;

            await _feedFileRepository.Save(FeedFileInfo);

            return RedirectToPage("./View", new { FileId });
        }

    }
}