using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.FtpServer.ReadModel.Repos;
using RealSoftware.FtpServer.ReadModel;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Feed
{
    public class IndexModel : PageModel
    {
        private readonly IFeedFileRepository _feedFileRepository;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            IFeedFileRepository feedFileRepository,
            ILogger<IndexModel> logger
        )
        {
            _feedFileRepository = feedFileRepository;
            _logger = logger;
        }

        public List<FeedFile> Files { get; set; }

        [BindProperty(SupportsGet = true)]
        public string Username { get; set; }

        public async Task OnGetAsync()
        {
            if (string.IsNullOrWhiteSpace(Username))
            {
                Files = (await _feedFileRepository.GetAllAsync(200)).OrderByDescending(x => x.UploadedAt).Take(200).ToList();
            }
            else
            {
                Files = (await _feedFileRepository.GetAllByUserAsync(Username, 200)).OrderByDescending(x => x.UploadedAt).ToList();
            }
        }

        public async Task<IActionResult> OnPostEnableReprocessingAsync(Guid fileId)
        {
            var feedFile = await _feedFileRepository.GetByFileId(fileId);

            if (feedFile == null || feedFile.Status.HasValue && feedFile.Status.Value == FileStatus.Processed)
            {
                return RedirectToPage("./Index");
            }

            feedFile.AllowReprocess = true;

            await _feedFileRepository.Save(feedFile);

            return RedirectToPage("./Index");

        }
    }
}
