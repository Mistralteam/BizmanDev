using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.ReadModel.Repo;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Media
{
    public class IndexModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly ClientMediaRepo _clientMediaRepo;
        private readonly IFileStorage _fileStorage;

        public IndexModel(
            ClientMediaRepo clientMediaRepo,
            IClientRepository clientRepository,
            IFileStorage fileStorage
        )
        {
            _clientMediaRepo = clientMediaRepo;
            _clientRepository = clientRepository;
            _fileStorage = fileStorage;
        }

        public async Task OnGetAsync()
        {
            Client = await _clientRepository.GetByIdAsync(ClientId);

            if (Client == null)
            {
                RedirectToPage("../Index");
            }


            var files = await _clientMediaRepo.List(ClientId);

            Files = files;



        }

        [FromRoute]
        public Guid ClientId { get; set; }

        public Listing.ReadModels.Client Client { get; set; }

        public List<ReadModel.ClientMedia> Files { get; set; }
    }
}