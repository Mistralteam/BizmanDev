using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.ReadModel;
using RealSoftware.Management.ReadModel.Repo;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Forms
{
    public class IndexModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly ClientFormRepository _formRepository;
        private readonly IFileStorage _fileStorage;

        public IndexModel(
            ClientFormRepository formRepository,
            IClientRepository clientRepository,
            IFileStorage fileStorage
        )
        {
            _formRepository = formRepository;
            _clientRepository = clientRepository;
            _fileStorage = fileStorage;
        }

        public async Task OnGetAsync()
        {

            Client = await _clientRepository.GetByIdAsync(ClientId);

            if (Client == null)
            {
                RedirectToPage("../Index");
            }



            Forms = await _formRepository.GetAllForClient<ReadModel.GenericClientFormBase>(Client.ClientId);



        }

        [FromRoute]
        public Guid ClientId { get; set; }

        public Listing.ReadModels.Client Client { get; set; }

        [BindProperty]
        public NewFormRequest NewFormRequest { get; set; }






        public List<ReadModel.ClientForms<ReadModel.GenericClientFormBase>> Forms { get; set; }


        public async Task<IActionResult> OnPostCreateNewFormAsync([FromForm] NewFormRequest request)
        {
            if (request == null)
            {

                return RedirectToPage("./Index", new { ClientId = ClientId });

            }

            Client = await _clientRepository.GetByIdAsync(ClientId);


            switch (request.FormType)
            {
                case FormType.FacebookApp:
                    {

                        await _formRepository.CreateAysnc(new ReadModel.ClientForms<ReadModel.Forms.FacebookApp>
                        {
                            ClientId = Client.ClientId,
                            FormId = Guid.NewGuid(),
                            Status = FormStatus.Sent,
                            Type = FormType.FacebookApp,
                            LastUpdated = DateTimeOffset.Now,
                        });
                        break;
                    }
                default:
                    {
                        break;
                    }
            }




            return RedirectToPage("./Index", new { ClientId = ClientId });

        }
    }

    public class NewFormRequest
    {
        public FormType FormType { get; set; }
    }
}