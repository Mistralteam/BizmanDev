using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.ReadModel;
using RealSoftware.Management.ReadModel.Forms;
using RealSoftware.Management.ReadModel.Repo;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Forms
{
    public class ViewModel : PageModel
    {
        private readonly ClientFormRepository _clientFormRepo;
        private readonly IClientRepository _clientRepository;

        public ViewModel(
            ClientFormRepository clientFormRepo,
            IClientRepository clientRepository
        )
        {
            _clientFormRepo = clientFormRepo;
            _clientRepository = clientRepository;
        }

        [FromRoute]
        public Guid? FormId { get; set; }

        [FromRoute]
        public Guid ClientId { get; set; }

        public ReadModel.GenericClientFormBase Form { get; set; }

        public Listing.ReadModels.Client Client { get; set; }

        public bool Completed { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (!FormId.HasValue || FormId.Value == Guid.Empty)
            {
                return Redirect("/not-found");
            }

            Client = await _clientRepository.GetByIdAsync(ClientId);


            var form = await _clientFormRepo.GetAsync<ReadModel.Forms.FacebookApp>(FormId.Value);

            if (form.Status == ReadModel.FormStatus.Complete)
            {
                Form = form.FormData;
                Completed = true;
                return Page();
            }


            Form = form.FormData ?? new ReadModel.Forms.FacebookApp
            {
                Type = FormType.FacebookApp
            };


            return Page();
        }

    }
}