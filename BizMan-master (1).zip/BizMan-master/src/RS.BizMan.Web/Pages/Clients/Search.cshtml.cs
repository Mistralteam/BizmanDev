using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients
{
    public class SearchModel : PageModel
    {

        public string RedirectUrl { get; set; }

        public void OnGet()
        {

        }
    }
}