using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.ApiClients;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients
{
    public class EditModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly IPortalClientApi _clientApi;
        private readonly FacebookPageRepository _facebookPageRepository;
        private readonly ILogger<IndexModel> _logger;

        public EditModel(
            IClientRepository clientRepository,
            IPortalClientApi clientApi,
            FacebookPageRepository facebookPageRepository,
            ILogger<IndexModel> logger
        )
        {
            _clientRepository = clientRepository;
            this._clientApi = clientApi;
            _facebookPageRepository = facebookPageRepository;
            _logger = logger;
        }

        [BindProperty]
        public Client Client { get; set; }

        public List<string> Products { get; set; }

        [BindProperty]
        public Client.Contact PrimaryContact { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        public bool IsClientExist { get; set; }

        public bool FacebookTabsCreated { get; set; }

        public async Task OnGetAsync()
        {
            if (ClientId.HasValue)
            {
                Client = await _clientRepository.GetByIdAsync(ClientId.Value);

                if (!string.IsNullOrWhiteSpace(Client.FacebookPageId))
                {
                    var fbpage = await _facebookPageRepository.GetAsync(Client.FacebookPageId);
                    FacebookTabsCreated = fbpage != null;
                }

                var primaryContact = Client.Contacts?.Where(x => x.Type == Client.ContactType.Primary).FirstOrDefault();

                if (primaryContact != null)
                {
                    PrimaryContact = primaryContact;
                }
                else
                {
                    PrimaryContact = new Client.Contact
                    {
                        Id = Guid.NewGuid(),
                        Type = Client.ContactType.Primary
                    };
                }

                var portalClient = await _clientApi.GetClient(ClientId.Value);

                IsClientExist = portalClient.IsSuccessStatusCode && portalClient.Content != null;

                if(IsClientExist){
                    Products = portalClient.Content?.Products;
                }

                return;
            }

            Client = new Client();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (Client.ClientId == Guid.Empty)
            {
                Client.ClientId = Guid.NewGuid();
            }

            Client.Contacts = Client.Contacts ?? new List<Client.Contact>();

            var primaryContact = Client.Contacts?.Where(x => x.Type == Client.ContactType.Primary).FirstOrDefault();

            if (primaryContact != null)
            {
                Client.Contacts.Remove(primaryContact);
            }

            Client.Contacts.Add(PrimaryContact);


            await _clientRepository.SaveAsync(Client);

            return RedirectToPage(new { ClientId = Client.ClientId });
        }

        public async Task<IActionResult> OnPostAddClientToPortalAsync()
        {
            if (Client.ClientId == Guid.Empty)
            {
                return RedirectToPage("./Index");
            }

            Client = await _clientRepository.GetByIdAsync(Client.ClientId);


            // var primaryContact = Client.Contacts.Where(x => x.Type == Client.ContactType.Primary).FirstOrDefault();

            var contacts = new List<CreateClientRequest.Contact>();
            // if (primaryContact != null)
            {
                // var name = primaryContact.DisplayName.Split(' ');
                contacts.Add(new CreateClientRequest.Contact
                {
                    Id = Guid.NewGuid(),// primaryContact.Id,
                    // FirstName = name.First(),
                    // LastName = name.Last(),
                    FirstName = "Fname",
                    LastName = "Lname",
                    Email = "elijahabte@gmail.com",//primaryContact.Email,
                    Type = ApiClients.ContactType.Primary
                });
            }

            CreateClientRequest model = new CreateClientRequest
            {
                ClientId = Client.ClientId,
                Name = Client.Name ?? "test",
                CompanyName = Client.CompanyName ?? "Hello",
                Contacts = contacts,
            };
            await _clientApi.CreateClient(model);

            return RedirectToPage(new { ClientId = Client.ClientId });
        }

        public async Task<IActionResult> OnPostAddFacebookTabsAsync()
        {
            if (Client.ClientId == Guid.Empty)
            {
                return RedirectToPage("./Index");
            }

            Client = await _clientRepository.GetByIdAsync(Client.ClientId);

            await CreateClientFacebookTabs(Client);

            return RedirectToPage(new { ClientId = Client.ClientId });
        }


        public async Task CreateClientFacebookTabs(Client client)
        {

            var fbPage = await _facebookPageRepository.GetAsync(client.FacebookPageId);

            if (fbPage != null) return;


            fbPage = new ClientFacebookPage
            {
                ClientId = client.ClientId,
                PageId = client.FacebookPageId,
                Tabs = new List<ClientFacebookPage.Tab>
                {
                    new ClientFacebookPage.Tab{
                        Page = ClientFacebookPage.TabPage.BrowseProperties,
                        TabName = "BROWSE PROPERTIES"
                    },
                    new ClientFacebookPage.Tab{
                        Page = ClientFacebookPage.TabPage.Inspections,
                        TabName = "INSPECTIONS"
                    },
                    new ClientFacebookPage.Tab{
                        Page = ClientFacebookPage.TabPage.Sold,
                        TabName = "SOLD"
                    },
                    new ClientFacebookPage.Tab{
                        Page =ClientFacebookPage.TabPage.Reviews,
                        TabName = "CLIENT REVIEWS"
                    },
                    new ClientFacebookPage.Tab{
                        Page = ClientFacebookPage.TabPage.Appraisal,
                        TabName = "REQUEST APPRAISAL"
                    },
                    new ClientFacebookPage.Tab{
                        Page = ClientFacebookPage.TabPage.Contact,
                        TabName = "CONTACT US"
                    }

                }
            };

            await _facebookPageRepository.SaveAsync(fbPage);
        }
    }
}
