using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.S3;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Processing;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Agents
{
    public class EditModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly IAgentRepository _agentRepository;
        private readonly IFileStorage _fileStorage;
        private readonly IAmazonS3 _s3Client;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        private readonly ILogger<IndexModel> _logger;

        public EditModel(
            IClientRepository clientRepository,
            IAgentRepository agentRepository,
            IFileStorage fileStorage,
            IAmazonS3 s3Client,
            IConfiguration configuration,
            IWebHostEnvironment environment,
            ILogger<IndexModel> logger
        )
        {
            _clientRepository = clientRepository;
            _agentRepository = agentRepository;
            this._fileStorage = fileStorage;
            this._s3Client = s3Client;
            this._configuration = configuration;
            this._environment = environment;
            _logger = logger;
        }

        [BindProperty]
        public Client Client { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        [BindProperty]
        public Agent Agent { get; set; }

        [BindProperty(SupportsGet = true)]
        public string AgentId { get; set; }
        
        [BindProperty]
        public bool IsResize { get; set; } =true;

        [BindProperty]
        public IFormFile ProfilePicture { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (!ClientId.HasValue)
            {
                return RedirectToPage("../Clients/Index");
            }


            Client = await _clientRepository.GetByIdAsync(ClientId.Value);

            if (Client == null)
            {
                return RedirectToPage("../Clients/Index");
            }

            if (string.IsNullOrEmpty(AgentId) || AgentId.Equals("new", StringComparison.InvariantCultureIgnoreCase))
            {
                Agent = new Agent
                {
                    Id = Guid.NewGuid(),
                    AgentId = Guid.NewGuid().ToString(),
                    ClientId = ClientId.Value,
                };

            }
            else
            {
                Agent = await _agentRepository.GetClientAgentId(ClientId.Value, AgentId);
            }


            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (Client.ClientId == Guid.Empty)
            {
                return RedirectToPage("../Clients/Index");
            }

            Client = await _clientRepository.GetByIdAsync(ClientId.Value);

            if (Agent.ClientId != Client.ClientId)
            {
                return RedirectToPage("../Clients/Index");
            }

            if (ProfilePicture == null || ProfilePicture.Length == 0)
            {
                await _agentRepository.Save(Agent);
                return RedirectToPage(new { ClientId = Client.ClientId, AgentId = Agent.AgentId });
            }

            var resourcePath = string.Format("img/{0}/{1}.jpg", Client.Name.Replace(" ", "-"), Agent.Name.Replace(" ", "-").Replace("'", ""));
            var url = string.Format("{0}/{1}", _configuration["PublicCdnUrl"], resourcePath);
            await using (var originalImage = new MemoryStream())
            {
                await ProfilePicture.CopyToAsync(originalImage);
                originalImage.Position = 0;
                using (var thumbStream = new MemoryStream())
                using (var image = Image.Load(originalImage))
                {
                    if (IsResize)
                    {
                        if (image.Width > 600)
                        {
                            var jpegEncoder1 = new JpegEncoder
                            {
                                Quality = originalImage.Length > 128000 ? 80 : 100
                            };

                            var clone = image.Clone(context => context
                                .Resize(new ResizeOptions
                                {
                                    Mode = ResizeMode.Min,
                                    Size = new Size(600, 900)
                                }));
                            clone.Save(thumbStream, jpegEncoder1);
                            thumbStream.Position = 0;
                            await _fileStorage.SaveFile(thumbStream, _configuration["PublicCdnBucketName"], resourcePath);
                        }
                        else
                        {
                            await _fileStorage.SaveFile(originalImage, _configuration["PublicCdnBucketName"], resourcePath);
                        }

                    }
                    else
                    {
                        await _fileStorage.SaveFile(originalImage, _configuration["PublicCdnBucketName"], resourcePath);
                    }
                }
                if (_environment.EnvironmentName == "Production")
                {
                    await _s3Client.MakeObjectPublicAsync(_configuration["PublicCdnBucketName"], resourcePath, true);
                }

                Agent.ProfilePicture = url;

                await _agentRepository.Save(Agent);

            }



            return RedirectToPage(new { ClientId = Client.ClientId, AgentId = Agent.AgentId });
        }
    }
}
