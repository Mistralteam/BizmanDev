using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Agents
{
    public class IndexModel : PageModel
    {
        private readonly IAgentRepository _agentRepository;
        private readonly IClientRepository _clientRepository;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            IAgentRepository listingAgentRepository,
            IClientRepository clientRepository,
            ILogger<IndexModel> logger
        )
        {
            _agentRepository = listingAgentRepository;
            this._clientRepository = clientRepository;
            _logger = logger;
        }

        public List<Agent> Agents { get; set; }

        [FromRoute]
        public Guid ClientId { get; set; }
        public Client Client { get; set; }

        public async Task OnGetAsync()
        {
            if (ClientId != Guid.Empty)
            {
                Client = (await _clientRepository.GetByIdAsync(ClientId));
                Agents = (await _agentRepository.GetAllByClientId(ClientId)).ToList();
                return;
            }

            RedirectToPage("/Index");


            // Agents = (await _agentRepository.GetAll()).ToList();
        }
    }
}
