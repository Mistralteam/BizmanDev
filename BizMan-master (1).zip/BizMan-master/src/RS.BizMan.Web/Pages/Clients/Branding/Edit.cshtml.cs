using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.S3;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Branding
{
    public class EditModel : PageModel
    {
        private readonly IBrandingRepository _brandingRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IFileStorage _fileStorage;
        private readonly IAmazonS3 _s3Client;
        private readonly IConfiguration _configuration;
        private readonly ILogger<IndexModel> _logger;

        public EditModel(
            IBrandingRepository brandingRepository,
            IClientRepository clientRepository,
            IFileStorage fileStorage,
            IAmazonS3 s3Client,
            IConfiguration configuration,
            ILogger<IndexModel> logger
        )
        {
            _brandingRepository = brandingRepository;
            this._clientRepository = clientRepository;
            this._fileStorage = fileStorage;
            this._s3Client = s3Client;
            this._configuration = configuration;
            _logger = logger;
        }

        [BindProperty]
        public RealSoftware.Listing.ReadModels.Branding Branding { get; set; }

        [FromRoute]
        public Guid ClientId { get; set; }
        public Client Client { get; set; }

        public async Task OnGetAsync()
        {
            if (ClientId != Guid.Empty)
            {
                Client = await _clientRepository.GetByIdAsync(ClientId);
                Branding = await _brandingRepository.GetAsync(ClientId);

                return;
            }

            Branding = new RealSoftware.Listing.ReadModels.Branding();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (Branding.ClientId == Guid.Empty)
            {
                Branding.ClientId = ClientId;
            }

            Client = await _clientRepository.GetByIdAsync(Branding.ClientId);

            var logo = Request.Form.Files.GetFile("Logo");
            if (logo != null)
            {
                var url = await SaveImage("logo", logo);
                Branding.Styles.LogoImg = url;
            }

            var footerLogo = Request.Form.Files.GetFile("ClientFooterLogo");
            if (footerLogo != null)
            {
                var url = await SaveImage("footer-logo", footerLogo);
                Branding.Styles.ClientFooterLogoUrl = url;
            }

            var heroBannerImage = Request.Form.Files.GetFile("HeroBannerImage");
            if (heroBannerImage != null)
            {
                var url = await SaveImage("cover-image", heroBannerImage);
                Branding.Styles.HeroBannerImage = url;
            }

            await _brandingRepository.SaveAsync(Branding);

            return RedirectToPage(new { ClientId = Branding.ClientId });
        }

        private async Task<string> SaveImage(string imageName, IFormFile logo)
        {
            var ext = Path.GetExtension(logo.FileName);

            var resourcePath = string.Format("img/{0}/{1}{2}", Client.Name.Replace(" ", "-"), imageName, ext);
            var url = string.Format("{0}/{1}", _configuration["PublicCdnUrl"], resourcePath);

            using (var originalImage = new MemoryStream())
            {
                logo.OpenReadStream().CopyTo(originalImage);

                await _fileStorage.SaveFile(originalImage, _configuration["PublicCdnBucketName"], resourcePath);
            }


            await _s3Client.MakeObjectPublicAsync(_configuration["PublicCdnBucketName"], resourcePath, true);
            return url;
        }
    }
}
