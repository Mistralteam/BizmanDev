using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients.Listings
{
    public class IndexModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly IConfiguration _configuration;


        [FromRoute]
        public Guid ClientId { get; set; }

        public Listing.ReadModels.Client Client { get; set; }

        public string ListingApiUrl => _configuration["BizMan:Url"];

        public IndexModel(IClientRepository clientRepository, IConfiguration configuration)
        {
            _clientRepository = clientRepository;
            _configuration = configuration;
        }
        public async Task OnGetAsync()
        {
            Client = await _clientRepository.GetByIdAsync(ClientId);

            if (Client == null)
            {
                RedirectToPage("../Index");
            }


        }
    }
}
