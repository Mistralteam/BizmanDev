using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Clients
{
    public class IndexModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            IClientRepository clientRepository,
            ILogger<IndexModel> logger
        )
        {
            _clientRepository = clientRepository;
            _logger = logger;
        }

        public List<Client> Clients { get; set; }

        public async Task OnGetAsync()
        {
            Clients = (await _clientRepository.GetAllAsync()).OrderBy(x => x.Name).ToList();
        }
    }
}
