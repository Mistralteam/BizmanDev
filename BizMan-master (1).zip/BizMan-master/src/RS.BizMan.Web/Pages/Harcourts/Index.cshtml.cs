using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RealSoftware.FtpServer.ReadModel.Repos;
using RealSoftware.Listing.ReadModels.Repository;
using RealSoftware.Listing.Web.Repository;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Harcourts
{
    public class IndexModel : PageModel
    {
        private readonly IHarcourtFeedsRepository _harcourtFeedsRepository;
        private readonly IClientRepository _clientRespository;

        public IndexModel(IHarcourtFeedsRepository harcourtFeedsRepository, IClientRepository clientRespository)
        {
            this._harcourtFeedsRepository = harcourtFeedsRepository;
            this._clientRespository = clientRespository;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var harcourtsFeeds = await _harcourtFeedsRepository.GetAllAsync();
            var clients = await _clientRespository.GetAllAsync();

            Feeds = harcourtsFeeds.Select(x => new HarcourtsFeedViewModel
            {
                ClientId = x.ClientId,
                ClientName = clients.SingleOrDefault(c => c.ClientId == x.ClientId)?.Name ?? "Unkown",
                Feed = x
            }).ToList();

            return Page();
        }

        public IEnumerable<HarcourtsFeedViewModel> Feeds { get; set; }
    }

    public class HarcourtsFeedViewModel
    {
        public string ClientName { get; set; }
        public Guid ClientId { get; set; }
        public RealSoftware.FtpServer.ReadModel.HarcourtFeed Feed { get; set; }

    }
}