using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using RealSoftware.FtpServer.ReadModel.Repos;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.ReadModels.Repository;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.Data;

namespace RealSoftware.Management.FacebookApp.Web.Pages.Harcourts
{
    public class AddModel : PageModel
    {
        private readonly IHarcourtFeedsRepository _harcourtFeedsRepository;
        private readonly IClientRepository _clientRespository;
        private readonly IFeedAgentMapRepository _feedAgentMapRepository;

        public AddModel(
            IHarcourtFeedsRepository harcourtFeedsRepository,
            IClientRepository clientRespository,
            IFeedAgentMapRepository feedAgentMapRepository
            )
        {
            this._harcourtFeedsRepository = harcourtFeedsRepository;
            this._clientRespository = clientRespository;
            this._feedAgentMapRepository = feedAgentMapRepository;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public List<Client> Clients { get; set; }

        public async Task OnGetAsync()
        {
            Clients = await _clientRespository.GetAllAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid || Input.OfficeId == 0 || Input.ClientId == Guid.Empty)
            {
                await OnGetAsync();
                return Page();
            }



            await _harcourtFeedsRepository.Save(new FtpServer.ReadModel.HarcourtFeed
            {
                Id = Guid.NewGuid(),
                ClientId = Input.ClientId,
                OfficeId = Input.OfficeId
            });

            await _feedAgentMapRepository.Save(new FeedAgentMap
            {
                ClientId = Input.ClientId,
                AgentId = $"H{Input.OfficeId}",
            });

            return RedirectToPage("./Index");
        }


        public string ClientsJson => JsonConvert.SerializeObject(Clients);

        // public string OfficesJson => JsonConvert.SerializeObject(HarcourtsOffice.Offices);

        public async Task<IActionResult> OnGetOfficeSearchAsync([FromQuery] string name)
        {

            if (string.IsNullOrEmpty(name))
            {
                return new JsonResult(new
                {
                    results = HarcourtsOffice.Offices
                });
            }


            HarcourtsOffice[] harcourtsOffices = HarcourtsOffice.Offices.Where(x =>
                               x.OrganisationalUnitName.Contains(name, StringComparison.InvariantCultureIgnoreCase) ||
                               x.FindAnOfficeDisplaySuburbName.Contains(name, StringComparison.InvariantCultureIgnoreCase)
                            ).ToArray();

            return new JsonResult(new
            {
                results = harcourtsOffices
            });
        }


        public class InputModel
        {
            public int OfficeId { get; set; }
            public Guid ClientId { get; set; }
        }
    }
}