using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.Repos;

namespace RealSoftware.Management.FacebookApp.Web.Pages.FtpAccounts
{
    public class IndexModel : PageModel
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            IUserRepository userRepository,
            ILogger<IndexModel> logger
        )
        {
            _userRepository = userRepository;
            _logger = logger;
        }

        public List<FtpServer.ReadModel.FTPUser> FtpUsers { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        public Client Client { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {

            if (!ClientId.HasValue)
            {
                return RedirectToPage("../Clients/Index");
            }

            FtpUsers = await _userRepository.GetAllByClientId(ClientId.Value);

            return Page();
        }
    }
}
