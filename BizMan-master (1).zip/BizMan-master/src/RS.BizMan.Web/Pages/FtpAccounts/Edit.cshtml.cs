using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CloudFlare.Client;
using CloudFlare.Client.Enumerators;
using CloudFlare.Client.Exceptions;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RealSoftware.Listing.ReadModels;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.Config;
using RealSoftware.Management.FacebookApp.Web.Repos;

namespace RealSoftware.Management.FacebookApp.Web.Pages.FtpAccounts
{
    public class EditModel : PageModel
    {
        private readonly IClientRepository _clientRepository;
        private readonly IUserRepository _userRepository;
        private readonly ICloudFlareClient _cloudFlareClient;
        private readonly IOptions<CloudFlareAuthOptions> _cloudFlareOptions;
        private readonly IConfiguration _config;
        private readonly ILogger<IndexModel> _logger;

        public EditModel(
            IUserRepository userRepository,
            IClientRepository clientRepository,
            ICloudFlareClient cloudFlareClient,
            IOptions<CloudFlareAuthOptions> cloudFlareOptions,
            IConfiguration config,
            ILogger<IndexModel> logger
        )
        {
            _userRepository = userRepository;
            _clientRepository = clientRepository;
            _cloudFlareClient = cloudFlareClient;
            _cloudFlareOptions = cloudFlareOptions;
            this._config = config;
            _logger = logger;
        }

        [BindProperty]
        public FtpServer.ReadModel.FTPUser User { get; set; }

        public Listing.ReadModels.Client Client { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? ClientId { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid? UserId { get; set; }

        [BindProperty]
        public UserInputModel InputModel { get; set; }

        public UserCreated UserDetails { get; set; }



        public async Task<IActionResult> OnGetAsync()
        {
            if (!ClientId.HasValue)
            {
                return RedirectToPage("../Clients/Index");
            }


            Client = await _clientRepository.GetByIdAsync(ClientId.Value);

            if (Client == null)
            {
                return RedirectToPage("../Clients/Index");
            }

            if (!UserId.HasValue)
            {
                User = new FtpServer.ReadModel.FTPUser
                {
                    Id = Guid.NewGuid(),
                    ClientId = ClientId.Value,
                };
                InputModel = new UserInputModel
                {
                    Username = "",
                    IPRestriction = User.IPAddressRestriction,
                    SetPassword = true
                };

            }
            else
            {
                User = (await _userRepository.GetAllByClientId(ClientId.Value)).Single(x => x.Id == UserId.Value);
                InputModel = new UserInputModel
                {
                    Username = GetUserPortionOfEmail(User.Username),
                    IPRestriction = User.IPAddressRestriction,
                };
            }



            return Page();

        }

        private string GetUserPortionOfEmail(string username)
        {
            return username.Contains('@') ? username.Split('@')[0] : username;
        }

        public async Task<IActionResult> OnPostAsync()
        {

            if (!ModelState.IsValid) return Page();

            UserId = UserId.HasValue ? UserId : Guid.NewGuid();
            User = (await _userRepository.GetAllByClientId(ClientId.Value)).SingleOrDefault(x => x.Id == UserId.Value);

            if (User?.Id == null || User?.Id == Guid.Empty)
            {
                User = new FtpServer.ReadModel.FTPUser
                {
                    Id = UserId.Value,
                    ClientId = ClientId.Value,
                    IPAddressRestriction = "*"

                };
            }
            string password = null;
            if (InputModel.SetPassword)
            {
                password = !string.IsNullOrWhiteSpace(InputModel.Password) ? InputModel.Password : Guid.NewGuid().ToString();
            }


            string userName = InputModel.Username + "@ftp.realsoftware.com.au";

            User.Username = userName;
            User.NormalizedUsername = userName.ToUpperInvariant();
            if (!string.IsNullOrWhiteSpace(password))
            {
                User.PasswordHash = GetPassswordHash(User, password);

                UserDetails = new UserCreated
                {
                    User = userName,
                    Password = password,
                };
            }

            await _userRepository.Save(User);

            return await OnGetAsync();


            // return RedirectToPage(new { ClientId = User.ClientId, UserId = User.Id });
        }

        private string GetPassswordHash(FtpServer.ReadModel.FTPUser user, string password)
        {
            var hasher = new PasswordHasher<FtpServer.ReadModel.FTPUser>();
            return hasher.HashPassword(user, password);
        }
    }

    public class UserCreated
    {
        public string Host { get; set; } = "ftp.realsoftware.com.au";
        public string User { get; set; }
        public string Password { get; set; }
        public string Directory { get; set; } = "/";
    }

    public class UserInputModel
    {
        public string Username { get; set; }
        public string Password { get; set; }

        public bool SetPassword { get; set; }
        public string IPRestriction { get; set; }
        public bool Lockedout { get; set; }
    }
}
