using System.Net.Http;

namespace RealSoftware.Management.FacebookApp.Web.CloudFlare
{
    // public class CloudFlareWorkerRouteApi
    // {
    //     private readonly HttpClient _client;
    //     public CloudFlareWorkerRouteApi(HttpClient client)
    //     {
    //         this._client = client;
    //     }

    //     public 
    // }
}