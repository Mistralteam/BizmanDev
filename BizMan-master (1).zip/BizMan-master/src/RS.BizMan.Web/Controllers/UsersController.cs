﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RealSoftware.Management.Common;
using RealSoftware.Management.ReadModel;
using RealSoftware.Management.FacebookApp.Web.ApiClients;
using Microsoft.AspNetCore.Authorization;

namespace RealSoftware.Management.FacebookApp.Web.Controllers
{
    [Authorize]
    public class UsersController : Controller
    {
        private readonly IPortalUserApi _userApi;


        public UsersController(IPortalUserApi userApi)
        {
            _userApi = userApi;
        }
        public async Task<IActionResult> Index()
        {
            return View("~/pages/users/index.cshtml");
        }

        public async Task<IActionResult> UsersPartial()
        {
            var model = await _userApi.GetUsersForClient(Guid.NewGuid());
            return PartialView("~/pages/users/_UsersPartial.cshtml", model.Content);
        }

        [HttpGet]
        public async Task<IActionResult> AddNewUser(Guid ClientId)
        {
            return PartialView("~/pages/users/AddNewUser.cshtml", new User
            {
                ClientId = ClientId
            });
        }

        [HttpPost]
        public async Task<IActionResult> AddNewUser(CreateUserRequest item)
        {
            var res = await _userApi.CreateNewUser(new CreateUserRequest
            {
                ClientId = item.ClientId,
                Email = item.Email,
                FirstName = item.FirstName,
                LastName = item.LastName,
                Password = item.Password,
                UserId = Guid.NewGuid()
            });

            return Ok(new
            {
                isSucceed = true
            });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteUser(DeleteUserRequest request)
        {

            var res = await _userApi.DeleteUser(new DeleteUserRequest
            {
                UserId = request.UserId,
                ClientId = request.ClientId
            });

            if (!res.Content.Deleted)
            {
                return BadRequest();
            }

            return Ok();

        }
    }
}
