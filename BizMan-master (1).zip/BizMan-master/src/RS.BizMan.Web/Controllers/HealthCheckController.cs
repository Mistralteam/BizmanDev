using Microsoft.AspNetCore.Mvc;

namespace RS.BizMan.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class HealthCheckController : ControllerBase
    {
        [HttpGet]
        public void Index() => Ok();
    }
}