using System;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.FacebookApp.Web.ApiClients;

namespace RealSoftware.Management.FacebookApp.Web.Controllers
{
    [Authorize]
    [Route("api/client")]
    // [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly IClientRepository _clientRepository;
        private readonly IPortalClientApi _clientApi;

        public ClientController(
            IClientRepository clientRepository,
            IPortalClientApi clientApi
        )
        {
            _clientRepository = clientRepository;
            _clientApi = clientApi;
        }

        // [HttpPost("new")]
        // public async Task<IActionResult> NewClient([FromBody] CreateClientRequest request)
        // {
        //     // 


        //     return Ok();
        // }




        [HttpPost("add-product")]
        public async Task<IActionResult> AddProduct([FromForm]AddProductRequest request)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var client = await _clientRepository.GetByIdAsync(request.ClientId);

            if (client == null)
            {
                ModelState.AddModelError(nameof(request.ClientId), string.Format("Client with Id: '{0}' doesn't exist.", request.ClientId));

                return BadRequest(ModelState);
            }

            await _clientApi.AddProduct(new AddClientProductRequest
            {
                ClientId = request.ClientId,
                ProductName = request.ProductName.ToString()
            });

            return Ok();
        }
    }



    public class AddProductRequest
    {
        public Guid ClientId { get; set; }

        public ProductName ProductName { get; set; }
    }

    
    public enum ProductName
    {
        [EnumMember(Value = "Facebook App")]
        FacebookApp = 1,
        CRM = 2,
        [EnumMember(Value = "Agent Website")]
        AgentWebsite = 3,
        [EnumMember(Value = "Office Website")]
        OfficeWebsite = 4,
        [EnumMember(Value = "Domain Hosting")]
        DomainHosting = 5,
        [EnumMember(Value = "Email Hosting")]
        EmailHosting = 6,
    }
}