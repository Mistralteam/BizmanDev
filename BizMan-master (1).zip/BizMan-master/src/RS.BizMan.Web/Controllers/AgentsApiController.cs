﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using NEvilES.Abstractions.Pipeline.Async;
using RealSoftware.Common.Abstractions;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.Contracts;
using static RealSoftware.Management.Contracts.Agent;
using Amazon.S3;
using Microsoft.AspNetCore.Hosting;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Processing;
using System.Threading;

namespace RS.BizMan.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgentsApiController : ControllerBase
    {
        private readonly IAgentRepository _agentRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IConfiguration _configuration;
        private readonly IFileStorage _fileStorage;
        private readonly IAmazonS3 _s3Client;
        private readonly IWebHostEnvironment _environment;
        private readonly IAsyncCommandProcessor _commandProcessor;

        public AgentsApiController(
            IAgentRepository agentRepository,
            IClientRepository clientRepository,
            IConfiguration configuration,
            IFileStorage fileStorage,
            IAmazonS3 s3Client,
            IWebHostEnvironment environment
            )
        {
            _agentRepository = agentRepository;
            _clientRepository = clientRepository;
            _configuration = configuration;
            _fileStorage = fileStorage;
            _s3Client = s3Client;
            _environment = environment;
        }

        [HttpGet]
        public async Task<IActionResult> Get(Guid clientId)
        {
            return Ok(await _agentRepository.GetAllByClientId(clientId));
        }
        [HttpPost("{agentId?}")]
        public async Task<IActionResult> Post([FromForm] Agents.AddAgent item, [FromRoute] string agentId)
        {

            if (string.IsNullOrEmpty(agentId))
                agentId = Guid.NewGuid().ToString();

            var client = await _clientRepository.GetByIdAsync(item.ClientId);
            var agent = await _agentRepository.GetById(Guid.Parse(agentId));

            if (agent == null)
            {
                agent = new RealSoftware.Listing.ReadModels.Agent
                {
                    Id = Guid.Parse(agentId),
                    ClientId = client.ClientId,
                    AgentId = agentId,
                    Email = item.Email,
                    Mobile = item.Mobile,
                    Name = item.Name,
                };
            }
            else
            {
                agent.Email = item.Email;
                agent.Mobile = item.Mobile;
                agent.Name = item.Name;
            }


            if (item.Image != null)
            {
                var id = Guid.NewGuid();
                var resourcePath = string.Format("img/{0}/{1}-{2}.jpg", CleanAndFormatVariableForFileStore(client.Name), CleanAndFormatVariableForFileStore(item.Name), id);
                var absolutePublicUrl = $"{_configuration["PublicCdnUrl"]}/{resourcePath}";
                using var originalImage = new MemoryStream();

                // TODO: resize the files down here as well.
                await item.Image.CopyToAsync(originalImage);
                originalImage.Position = 0;
                using var thumbStream = new MemoryStream();
                using var image = Image.Load(originalImage);


                if (image.Width > 600)
                {
                    var jpegEncoder1 = new JpegEncoder
                    {
                        Quality = originalImage.Length > 128000 ? 80 : 100
                    };

                    var clone = image.Clone(context => context
                        .Resize(new ResizeOptions
                        {
                            Mode = ResizeMode.Min,
                            Size = new Size(600, 900)
                        }));
                    clone.Save(thumbStream, jpegEncoder1);
                    thumbStream.Position = 0;
                    await _fileStorage.SaveFile(thumbStream, _configuration["PublicCdnBucketName"], resourcePath);
                }
                else
                {
                    await _fileStorage.SaveFile(originalImage, _configuration["PublicCdnBucketName"], resourcePath);
                }


                if (_environment.EnvironmentName == "Production")
                {
                    await _s3Client.MakeObjectPublicAsync(_configuration["PublicCdnBucketName"], resourcePath, true);
                }

                agent.ProfilePicture = absolutePublicUrl;
            }


            await _agentRepository.Save(agent);

            return new JsonResult(new { });


        }

        [HttpGet("getbyid/{agentId}")]
        public async Task<IActionResult> GetById(Guid agentId)
        {
            return Ok(await _agentRepository.GetById(agentId));
        }

        private string CleanAndFormatVariableForFileStore(string dirtyValue)
        {
            return dirtyValue
                .Replace(" ", "-")
                .Replace("'", "")
                .Replace("\"", "")
                .Replace("/", "")
                .Replace("\\", "")
                .Replace("?", "")
                .Replace("*", "")
                .Replace("<", "")
                .Replace(">", "")
                .Replace("|", "");
        }
    }
}
