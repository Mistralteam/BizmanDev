﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using RealSoftware.Management.ReadModel;
using System.ComponentModel.DataAnnotations;
using RealSoftware.Common.Abstractions;
using Microsoft.Extensions.Options;
using RealSoftware.Management.ReadModel.Repo;
using Microsoft.Extensions.Logging;
using RealSoftware.Management.FacebookApp.Extension;

namespace RealSoftware.Management.Facebook.WebApp.Controllers.Public
{
    public class ClientMediaOptions
    {
        public string BucketName { get; set; }
    }




    [Route("api/public/media")]
    [ApiController]
    public class PublicMediaController : ControllerBase
    {
        private readonly ClientFormRepository _clientFormRepository;
        private readonly ClientMediaRepo _clientMediaRepo;
        private readonly IFileStorage _fileStorage;
        private readonly IOptions<ClientMediaOptions> _options;
        private readonly ILogger<PublicMediaController> _logger;

        public PublicMediaController(
            ClientFormRepository clientFormRepository,
            ClientMediaRepo clientMediaRepo,
            IFileStorage fileStorage,
            IOptions<ClientMediaOptions> options,
            ILogger<PublicMediaController> logger)
        {
            this._clientFormRepository = clientFormRepository;
            this._clientMediaRepo = clientMediaRepo;
            this._fileStorage = fileStorage;
            this._options = options;
            this._logger = logger;
        }

        // [HttpGet]
        // public async Task<IActionResult> GetFile([FromQuery] GetMediaRequestModel requestModel)
        // {
        //     if (!ModelState.IsValid || !requestModel.FormId.HasValue || requestModel.FormId.Value == Guid.Empty)
        //     {
        //         return NotFound();
        //     }

        //     var file = await _clientMediaRepo.Get(requestModel.FormId.Value);

        //     if (file == null)
        //     {
        //         return NotFound();
        //     }

        //     var s = await _fileStorage.GetFileStream(_options.Value.BucketName, file.FileKey);

        //     return File(s, file.ContentType, file.FileName, true);
        // }

        [HttpPost]
        public async Task<IActionResult> UploadMedia([FromForm] MediaUploadInputModel inputModel)
        {
            if (!ModelState.IsValid && !inputModel.FormId.HasValue || inputModel.FormId.Value == Guid.Empty)
            {
                return BadRequest(ModelState);
            }

            var form = await _clientFormRepository.GetAsync<ReadModel.Forms.FacebookApp>(inputModel.FormId.Value);

            if (form == null)
            {
                string errorMessage = string.Format("Form with Id '{0}' doesn't exist", inputModel.FormId.Value);
                ModelState.AddModelError(nameof(inputModel.FormId), errorMessage);

                return BadRequest(ModelState);
            }


            var fileId = Guid.NewGuid();
            string fileStorageKey = $"{fileId}_{inputModel.File.FileName}";

            var media = new ClientMedia
            {
                FileId = fileId,
                ClientId = form.ClientId,
                FileKey = fileStorageKey,
                FileName = inputModel.File.FileName,
                Size = inputModel.File.Length,
                ContentType = inputModel.File.ContentType,
                UploadedAt = DateTimeOffset.Now,
                Meatdata = new Dictionary<string, string>{
                    {"FormId", form.FormId.ToString()}
                },
                Tags = new List<string> { "Form" }
            };

            try
            {
                await _fileStorage.SaveFile(
                    inputModel.File.OpenReadStream(),
                    _options.Value.BucketName,
                    fileStorageKey//,
                                  // new Dictionary<string, string> {
                                  //     // { "RSFileId", fileId.ToString() }
                                  // }
                );

                await _clientMediaRepo.Create(media);

            }
            catch (Exception ex)
            {
                var errorMessage = string.Format("File Id: {0}, File Key: {1}.", fileId, fileStorageKey);
                _logger.LogError(ex, "Error occured uploading media. " + errorMessage);
            }

            return Ok(new UploadResponseModel
            {
                FormId = inputModel.FormId.Value,
                FileId = fileId,
                Media = media
            });

        }
    }

    public class UploadResponseModel
    {
        public Guid FormId { get; set; }
        public Guid FileId { get; set; }
        public ClientMedia Media { get; set; }
    }

    public class MediaUploadInputModel
    {
        [Required]
        public Guid? FormId { get; set; }

        [Required]
        public IFormFile File { get; set; }
    }

    public class GetMediaRequestModel
    {
        [Required]
        public Guid? FormId { get; set; }
    }

    public class ApplicationFormFile
    {
        public IFormFile Files { get; set; }
    }
}

