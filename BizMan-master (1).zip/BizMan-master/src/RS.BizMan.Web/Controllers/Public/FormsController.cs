using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RealSoftware.Listing.Web.Repository;
using RealSoftware.Management.Email.Services;
using RealSoftware.Management.ReadModel;
using RealSoftware.Management.ReadModel.Repo;
using SendGrid.Helpers.Mail;

namespace RealSoftware.Management.FacebookApp.Web.Controllers.Public
{

    [Route("api/public/[controller]")]
    public class FormsController : ControllerBase
    {
        private readonly ClientFormRepository _clientFormRepository;
        private readonly IClientRepository _clientRepository;
        private readonly ISendGirdEmailService _sendGirdEmailService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<FormsController> _logger;

        public FormsController(
            ClientFormRepository clientFormRepository,
            IClientRepository clientRepository,
            ISendGirdEmailService sendgirdEmailService,
            IConfiguration configuration,
            ILogger<FormsController> logger)
        {
            this._clientFormRepository = clientFormRepository;
            this._clientRepository = clientRepository;
            _sendGirdEmailService = sendgirdEmailService;
            _configuration = configuration;
            this._logger = logger;
        }

        [HttpGet("{id:guid?}")]
        public async Task<IActionResult> Get([FromRoute] Guid? id, [FromQuery] FormType? type = null)
        {
            if (!id.HasValue || id.Value == Guid.Empty) return NotFound();

            var form = await _clientFormRepository.GetAsync<ReadModel.Forms.FacebookApp>(id.Value);

            if (form == null) return NotFound();

            return Ok(form);
        }


        public async Task<IActionResult> GetFormStatus([FromBody] FormRequest request)
        {

            if (!ModelState.IsValid || request.FormId.HasValue && request.FormId.Value == Guid.Empty)
            {
                return BadRequest(ModelState);
            }

            var form = await _clientFormRepository.GetAsync<GenericClientFormBase>(request.FormId.Value);

            if (form != null)
            {
                return NotFound();
            }

            return Ok(new
            {
                FormId = form.FormId,
                Status = form.Status,
                Type = form.Type,
                LastUpdated = form.LastUpdated
            });
        }



        [HttpPost("{id:guid?}/save-facebook")]
        public async Task<IActionResult> UpdateFacebookForm([FromBody] Models.FacebookClient request)
        {
            if (request.FormId.HasValue && request.FormId.Value == Guid.Empty)
            {
                return BadRequest(ModelState);
            }

            var form = await _clientFormRepository.GetAsync<ReadModel.Forms.FacebookApp>(request.FormId.Value);

            if (form == null || form.Status == FormStatus.Complete)
            {
                return NotFound();
            }

            form.FormData = form.FormData ?? new ReadModel.Forms.FacebookApp();

            form.Status = FormStatus.InProgress;


            form.FormData.MainContact = new ReadModel.Forms.Contact
            {
                Email = request.MainContact?.Email,
                FirstName = request.MainContact?.FirstName,
                LastName = request.MainContact?.LastName,
                MobileNumber = request.MainContact?.MobileNumber
            };


            if (request.UseMainContactForAccounts == true)
            {
                form.FormData.Accounts = null;
            }
            else
            {
                form.FormData.Accounts = new ReadModel.Forms.Contact
                {
                    Email = request.Accounts?.Email,
                    FirstName = request.Accounts?.FirstName,
                    LastName = request.Accounts?.LastName,
                    MobileNumber = request.Accounts?.MobileNumber
                };
            }
            form.FormData.UseMainContactForAccounts = request.UseMainContactForAccounts ?? false;

            form.FormData.Name = request.Name;
            form.FormData.EnquiresEmail = request.EnquiresEmail;
            form.FormData.ListingUploader = request.ListingUploader;
            form.FormData.ListingUploaderOther = request.ListingUploaderOther;
            form.FormData.ClientReviews = (ReadModel.Forms.ClientReviewOptions)request.ClientReviews;
            form.FormData.OfficeAddress = request.OfficeAddress;
            form.FormData.OfficeWebsite = request.OfficeWebsite;
            form.FormData.PhoneNumber = request.PhoneNumber;
            form.FormData.TradingName = request.TradingName;
            form.FormData.ABN = request.ABN;


            form.FormData.Logo = request.Logo == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.Logo.FileId.Value,
                FileName = request.Logo.FileName,
                Tag = "a"
            };

            form.FormData.HeroImage = request.HeroImage == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.HeroImage.FileId.Value,
                FileName = request.HeroImage.FileName,
                Tag = "a"
            };

            form.FormData.StaffContactDetails = request.StaffContactDetails == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.HeroImage.FileId.Value,
                FileName = request.HeroImage.FileName,
                Tag = "a"
            };

            form.FormData.StaffPic1 = request.StaffPic1 == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.StaffPic1.FileId.Value,
                FileName = request.StaffPic1.FileName,
                Tag = "a"
            };

            form.FormData.StaffPic2 = request.StaffPic2 == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.StaffPic2.FileId.Value,
                FileName = request.StaffPic2.FileName,
                Tag = "a"
            };

            form.FormData.StaffPic3 = request.StaffPic3 == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.StaffPic3.FileId.Value,
                FileName = request.StaffPic3.FileName,
                Tag = "a"
            };

            form.FormData.StaffPic4 = request.StaffPic4 == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.StaffPic4.FileId.Value,
                FileName = request.StaffPic4.FileName,
                Tag = "a"
            };

            form.FormData.StaffPic5 = request.StaffPic5 == null ? null : new ReadModel.Forms.FileInfo
            {
                FileId = request.StaffPic5.FileId.Value,
                FileName = request.StaffPic5.FileName,
                Tag = "a"
            };

            form.FormData.OtherFiles = request.OtherFiles == null || request.OtherFiles.Count == 0 ? null : request.OtherFiles.Select(x =>
            {
                return new ReadModel.Forms.FileInfo
                {
                    FileId = x.FileId.Value,
                    FileName = x.FileName,
                    Tag = "a"
                };
            }).ToList();

            form.FormData.FacebookPageOwner = new ReadModel.Forms.FacebookPageOwner
            {
                Name = request.FacebookPageOwner.Name,
                Email = request.FacebookPageOwner.Email,
                MobileNumber = request.FacebookPageOwner.MobileNumber
            };
            form.FormData.Facebook = new ReadModel.Forms.FacebookDetails
            {
                Id = request.Facebook.Id,
                Name = request.Facebook.Name,
                Url = request.Facebook.Url,
            };


            await _clientFormRepository.SaveAsync(form, null);




            return Ok();
        }

        [HttpPost("{FormId:guid?}/complete")]
        public async Task<IActionResult> SetInProgress([FromRoute] FormCompleteRequest request)
        {

            if (!ModelState.IsValid || request.FormId.HasValue && request.FormId.Value == Guid.Empty)
            {
                return BadRequest(ModelState);
            }

            var genericForm = await _clientFormRepository.GetAsync<GenericClientFormBase>(request.FormId.Value);

            if (genericForm == null)
            {
                return NotFound();
            }


            (dynamic form, FormType formType) = await GetTypedClientFormAsync(request.FormId.Value);

            var validator = (IValidator)HttpContext.RequestServices.GetService(GetValidatorTypeForForm(formType));

            IValidationContext validatorContext = GetValidatorContextForForm(((dynamic)form).FormData, formType);

            var res = validator.Validate(validatorContext);


            if (!res.IsValid)
            {
                res.AddToModelState(ModelState, null);


                var errors = ModelState.ToDictionary(
                    kvp => string.Join('.', kvp.Key.Split('.').Select(k => System.Text.Json.JsonNamingPolicy.CamelCase.ConvertName(k))),
                    kvp => kvp.Value.Errors.Select(x => x.ErrorMessage).ToArray()
                );

                return BadRequest(errors);
            }

            form.Status = FormStatus.Complete;

            await SaveFormUpdates(form, formType);

            // await _clientFormRepository.SaveAsync(genericForm, genericForm.LastUpdated);
            // await _clientFormRepository.SaveAsync<ReadModel.Forms.FacebookApp>(((ClientForms<ReadModel.Forms.FacebookApp>)form), genericForm.LastUpdated);
            // await _clientFormRepository.SendEmailFormCompleted(request.FormId.Value);
            await SendEmailFormCompleted(genericForm.ClientId, request.FormId.Value);


            return Ok(new
            {
                FormId = genericForm.FormId,
                Status = form.Status,
                Type = genericForm.Type,
                LastUpdated = genericForm.LastUpdated
            });
        }

        private async Task SendEmailFormCompleted(Guid clientId, Guid formId)
        {
            var from = new EmailAddress()
            {
                Email = _configuration["SendGrid:From"],
                Name = _configuration["SendGrid:From"]
            };

            var client = await _clientRepository.GetByIdAsync(clientId);
            var baseLink = _configuration.GetValue<string>("BizMan:Url");

            var link = $"{baseLink}/Clients/{client.ClientId}/Form/{formId}";
            await _sendGirdEmailService.SendEmail(
                from,
                "Client Form Completed",
                $"<b>{client.Name} has completed the online form <a href='{link}'>click here</a> to view it.</b>",
                $"<b>{client.Name} has completed the online form <a href='{link}'>click here</a> to view it.</b>",
                new EmailAddress()
                {
                    Email = "info@realsoftware.com.au",
                    Name = "info@realsoftware.com.au"
                }
            );

        }


        private Task SaveFormUpdates(dynamic form, FormType formType) => formType switch
        {
            FormType.FacebookApp => _clientFormRepository.SaveAsync<ReadModel.Forms.FacebookApp>((ClientForms<ReadModel.Forms.FacebookApp>)form, form.LastUpdated),
            _ => throw new ArgumentException("Form Validator Type not implemented"),
        };


        private async Task<(object form, FormType type)> GetTypedClientFormAsync(Guid value)
        {
            var clientForm = await _clientFormRepository.GetAsync<ReadModel.Forms.FacebookApp>(value);



            return (clientForm, clientForm.Type);
        }

        private static IValidationContext GetValidatorContextForForm(object formData, FormType formType)
        {
            var genericTyped = typeof(FluentValidation.ValidationContext<>).MakeGenericType(GetTypeForForm(formType));

            var validationContext = Activator.CreateInstance(genericTyped, formData);

            return (IValidationContext)validationContext;
        }

        public static Type GetValidatorTypeForForm(FormType type) => type switch
        {
            FormType.FacebookApp => typeof(IValidator<ReadModel.Forms.FacebookApp>),
            _ => throw new ArgumentException("Form Validator Type not implemented"),
        };

        public static Type GetTypeForForm(FormType type) => type switch
        {
            FormType.FacebookApp => typeof(ReadModel.Forms.FacebookApp),
            _ => throw new ArgumentException("Form Validator Type not implemented"),
        };




    }





    public class FormRequest
    {
        [Required]
        public Guid? FormId { get; set; }
    }

    public class FormCompleteRequest
    {
        [Required]
        public Guid? FormId { get; set; }
    }
}