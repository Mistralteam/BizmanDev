﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RealSoftware.Listing.Web.Repository;
using Microsoft.AspNetCore.Authorization;

namespace RealSoftware.Management.FacebookApp.Web.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ListingApiController : ControllerBase
    {
        private readonly IListingRepository _listingRepository;

        public ListingApiController(IListingRepository listingRepository)
        {
            _listingRepository = listingRepository;
        }
        public async Task<IActionResult> Get(Guid clientId, string search = "")
        {
            var res = await _listingRepository.GetAllByClientId(clientId, 1000, new System.Threading.CancellationToken());
            search = search?.ToLower() ?? "";
            res = res.Where(x =>
                x.PropertyStatus.ToString().ToLower().Contains(search) ||
                x.Address.FullAddress.ToLower().Contains(search) ||
                x.ClientId.ToString().ToLower().Contains(search) ||
                x.AgentId.ToLower().Contains(search) ||
                x.UniqueId.ToLower().Contains(search) ||
                x.ListingId.ToString().Contains(search)

                );

            return Ok(res);
        }
    }
}
