#!/bin/bash

#install zip on debian OS, since microsoft/dotnet container doesn't have zip by default
if [ -f /etc/debian_version ]
then
  apt -qq update
  apt -qq -y install zip
fi

if [ -f ./build/RealSoftware.Management.FacebookApp.Web.zip ]
then
  rm ./build/RealSoftware.Management.FacebookApp.Web.zip
fi
dotnet restore

if [ -f /var/.dotnet-tools/dotnet-lambda ]
then
  /var/.dotnet-tools/dotnet-lambda package ./RealSoftware.Management.FacebookApp.Web.csproj --configuration release -o ../../build/RealSoftware.Management.FacebookApp.Web.zip
else
  dotnet lambda package ./RealSoftware.Management.FacebookApp.Web.csproj --configuration release -o ../../build/RealSoftware.Management.FacebookApp.Web.zip
fi


