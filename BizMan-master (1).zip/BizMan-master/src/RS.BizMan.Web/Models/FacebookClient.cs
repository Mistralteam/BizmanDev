﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using RealSoftware.Management.ReadModel.Forms;

namespace RealSoftware.Management.FacebookApp.Models
{
    // [DynamoDBTable("facebook-client")]
    public class FacebookClient
    {


        [Required]
        public Guid? ClientId { get; set; }

        [Required]
        public Guid? FormId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Display(Name = "Trading Name")]
        [Required(ErrorMessage = "Trading Name is required")]
        public string TradingName { get; set; }

        [Required(ErrorMessage = "ABN is required")]
        public string ABN { get; set; }

        [Display(Name = "Phone Number")]
        [Required(ErrorMessage = "Phone Number is required")]
        public string PhoneNumber { get; set; }

        [Display(Name = "Office Address")]
        [Required(ErrorMessage = "Office Address is required")]
        public string OfficeAddress { get; set; }

        [Required(ErrorMessage = "Office Website is required")]
        [Display(Name = "Office Website")]
        public string OfficeWebsite { get; set; }

        [Required]
        [Display(Name = "Client Reviews")]
        public ClientReviewOptions? ClientReviews { get; set; }

        // [Display(Name = "Office Website")]
        [Required]
        [Display(Name = "Listing Uploader")]
        public ListingFeedProvider? ListingUploader { get; set; }

        public string ListingUploaderOther { get; set; }

        public Contact MainContact { get; set; }
        public bool? UseMainContactForAccounts { get; set; }
        public Contact Accounts { get; set; }
        public FacebookDetails Facebook { get; set; }
        public FacebookBusinessPageOwner BusinessManager { get; set; }
        public FacebookPageOwner FacebookPageOwner { get; set; }
        public DateTimeOffset? LastUpdated { get; set; }
        public string EnquiresEmail { get; set; }


        public File? Logo { get; set; }
        public File? HeroImage { get; set; }
        public File? StaffContactDetails { get; set; }
        public File? StaffPic1 { get; set; }
        public File? StaffPic2 { get; set; }
        public File? StaffPic3 { get; set; }
        public File? StaffPic4 { get; set; }
        public File? StaffPic5 { get; set; }

        public List<File> OtherFiles { get; set; }
    }

    public enum ClientReviewOptions : int
    {
        RMA = 1,
        Google = 2,
        Facebook = 3,
        ClientProvided = 4,
    }

    public class FacebookDetails
    {
        public string Url { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
    }

    public class File
    {
        public string FileName { get; set; }
        public Guid? FileId { get; set; }
        public string FileUrl { get; set; }
    }


    public enum FacebookPageOwnershipType
    {
        Business,
        Individual
    }

    public class FacebookPageOwner
    {
        // public FacebookPageOwnershipType? OwnershipType { get; set; }
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
    }

    public class FacebookBusinessPageOwner
    {
        // public FacebookPageOwnershipType? OwnershipType { get; set; }
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string BusinessId { get; set; }
    }

    public class Contact
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
    }

    public class Reviews
    {

    }

    public class UploadFiles
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int FileSize { get; set; }
        public byte[] File { get; set; }
    }


}
