﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealSoftware.Management.Email.Model
{
    public class EmailModel
    {
        public string From { get; set; }
        public List<string> To { get; set; } = new();
        public List<string> CC { get; set; } = new();
        public List<string> BCC { get; set; } = new();
        public string Body { get; set; }
        public string Subject { get; set; }
    }
}
