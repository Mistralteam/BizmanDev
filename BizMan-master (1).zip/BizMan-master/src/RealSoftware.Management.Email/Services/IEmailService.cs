﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using RealSoftware.Management.Email.Model;
using MailKit;
using MimeKit;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;

namespace RealSoftware.Management.Email.Services
{
    public interface IEmailService
    {
        Task SendEmail(EmailModel item);
    }

    public class SendGridEmailService : IEmailService
    {
        public Task SendEmail(EmailModel item)
        {
            throw new NotImplementedException();
        }
    }

    public class EmailService : IEmailService
    {
        private readonly SmtpClient _smtpClient;

        public EmailService(SmtpClient smtpClient)
        {
            _smtpClient = smtpClient;
        }
        public async Task SendEmail(EmailModel item)
        {
           

            MimeMessage mailMessage = new MimeMessage();
            foreach (var _to in item.To)
            {
                mailMessage.To.Add(MailboxAddress.Parse(_to));

            }
            foreach (var _cc in item.CC)
            {
                mailMessage.Cc.Add(MailboxAddress.Parse(_cc));
            }
            foreach (var _bcc in item.BCC)
            {
                mailMessage.Bcc.Add(MailboxAddress.Parse(_bcc));
            }

            mailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Plain)
            {
                Text = item.Body
            };
            mailMessage.Subject = item.Subject;
            mailMessage.From.Add(MailboxAddress.Parse(item.From));
         
            await _smtpClient.SendAsync(mailMessage);

        }
    }
}
