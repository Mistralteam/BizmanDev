﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;
using DotLiquid;
using DotLiquid.NamingConventions;
using Microsoft.Extensions.Hosting;

namespace RealSoftware.Management.Email.Services
{
    public interface IEmailTemplateService
    {
        Task<string> RenderTemplate(string templateName, object model);
    }

    public class EmailTemplateService : IEmailTemplateService
    {
        private readonly IDynamoDBContext _db;

        private readonly string templatePath;
        public EmailTemplateService(IDynamoDBContext db)
        {
            _db = db;
        }

        public async Task<string> RenderTemplate(string templateName, object model)
        {

            /*string GetEmbeddedTemplate(Assembly ass, string root, string templatePath)
            {

                var basePath = templatePath.Contains("/")
                    ? Path.Combine(root, Path.GetDirectoryName(templatePath))
                    : root;

                var fileName = string.Format("{0}.liquid", Path.GetFileName(templatePath));

                var fullPath = Regex.Replace(Path.Combine(basePath, fileName), @"\\|/", ".");

                var stream = ass.GetManifestResourceStream(fullPath);
                if (stream == null)
                    throw new Exception("Template Not Found");

                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }



            Assembly assembly = typeof(EmailTemplateService).Assembly;
            const string Root = "RealSoftware.Management.Email.Templates";
            Template.FileSystem = new DotLiquid.FileSystems.EmbeddedFileSystem(assembly, Root);
            Template.NamingConvention = new CSharpNamingConvention();

            var templateString = GetEmbeddedTemplate(assembly, Root, templateName);*/
            var emailTemplates =await _db.ScanAsync<ReadModel.EmailTemplate>(new List<ScanCondition>()
            {
                new ScanCondition("Name",Amazon.DynamoDBv2.DocumentModel.ScanOperator.Equal,templateName)
            }).GetRemainingAsync();
            var templateString = emailTemplates.FirstOrDefault().Template;
            var template = Template.Parse(templateString);
            return template.Render(Hash.FromAnonymousObject(model));
        }
    }
}
