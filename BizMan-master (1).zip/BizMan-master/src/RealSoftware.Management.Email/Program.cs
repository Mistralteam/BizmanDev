﻿using Microsoft.Extensions.Hosting;
using System;
using MailKit.Net.Smtp;
using Microsoft.Extensions.DependencyInjection;
using RealSoftware.Management.Common;
using RealSoftware.Management.Email.Services;

namespace RealSoftware.Management.Email
{
    class Program
    {
        static void Main(string[] args)
        {
            var host = CreateHostBuilder(args);

            host.Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args)
            .UseConsoleLifetime()
            .ConfigureServices(
                (hostContext, services) =>
                {
                    services.AddSharedServices(hostContext.Configuration);
                    services.AddScoped<SmtpClient>();
                    services.AddScoped<IEmailService>( sp =>
                    {
                        SmtpClient smtpClient = new SmtpClient();
                        smtpClient.Connect("smtp.gmail.com", 587, false);
                        smtpClient.Authenticate("your email", "password");
                        return new EmailService(smtpClient);

                    });
                });

    }




}
