﻿using System;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NEvilES.Abstractions.Pipeline;
using RealSoftware.Management.Common;
using RealSoftware.Management.Tools;
using RealSoftware.Common.NEvilES;

namespace RealSoftware.Management.EventReplay
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            var config = new ConfigurationBuilder()
                .AddCommandLine(args)
                .AddEnvironmentVariables()
                .Build();


            var appBuilder = CreateHostBuilder(args, config).Build();

            var replayApp = appBuilder.Services.GetService<Replay.App>();

            await replayApp.Run();



        }

        public static IHostBuilder CreateHostBuilder(string[] args, IConfiguration configuration) =>
            Host.CreateDefaultBuilder(args)
               .ConfigureWebHost((w) =>
               {
                   w.UseConfiguration(configuration);
               })
                .ConfigureServices((hostContext, services) =>
                {
                    Console.WriteLine("TEST");
                    var b = hostContext.Configuration["AWS:Profile"];
                    Console.WriteLine(b);
                    services.AddScoped<Replay.App>();

                    services.AddSharedServices(hostContext.Configuration);
                    services.AddEventReplayServices(hostContext.Configuration, opts =>
                     {
                         opts.DomainAssemblyTypes = new Type[] {
                            typeof(Contracts.Contact),
                            typeof(Domain.Contact)
                         };

                         opts.GetUserContext = s => s.GetService<IUserContext>() ?? throw new Exception("User not authenticated");

                         opts.ReadModelAssemblyTypes = new Type[] {
                            typeof(ReadModel.Projectors.DynamoDb.ContactProjectors)
                         };

                     });
                });
    }

    public class SeedDataUser : IUser
    {
        public Guid GuidId => Guid.Parse("1fb46389-571c-4c16-82a6-9d9c0f471cfb");
    }
}
